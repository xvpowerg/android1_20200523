package tw.com.xvpower.firstappjava;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    enum Status{
        PASS,FAILL
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn =  findViewById(R.id.btn1);//找到畫面上的元件
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("Howard","Button Click!!");
            }
        });

        int value1 = 10;
        float price = 2.56f;
        final int value3 = 50;

       int valuex = value3 >= 20? 100: -50;

    String[] names = {"A","B","C"};


    }
}
