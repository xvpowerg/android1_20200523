package tw.com.xvpower.firstappkotlin

import android.util.Log
enum class Sex{
    Male,Female
}
fun test6Enum(sex:Sex){
    val msg =  when(sex){
        Sex.Female->"美女"
        Sex.Male->"帥哥"
    }
    Log.d("Howard","Male:${Sex.Male.ordinal}")
    Log.d("Howard","Female:${Sex.Female.ordinal}")
    Log.d("Howard",msg)
}
//測試var 與 val
//if else 測試
fun test1Kotlin(){
    //1 可不給類型 自動判斷
    var value1 = 3.1415
    //2 也可給類型
    var value2:Int = 70
    value2 = 20
    Log.d("Howard","value2:"+value2)
    //val 表示此變數為常數
    val value3:Int = 98
    //value3 = 21

    val msg:String = "price:$value3"
    Log.d("Howard",msg)
    val msg2:String = "number:$value3 / $value2"
    Log.d("Howard",msg2)
    val msg3:String = "number:${value3 / value2}"
    Log.d("Howard",msg3)
    val path = """c:\myfile\vallue.txt"""
    Log.d("Howard",path)
    val context = """ABC 
            DEF
            GHI
            """
    Log.d("Howard",context)
    val ifmsg = if (value2 >= 30){
        value2++
        "$value2 大於30"//可回傳
    }else{
        value2++
        Log.d("Howard","........")
        "$value2 小於30"//可回傳
    }
    Log.d("Howard",ifmsg)
    value1 =  if(value2 > 10) 2.71828 else 3.1415
}
fun test2When(action:Int){
    when(action){
        1 ->{ Log.d("Howard","Jump")}
        2 ->{ Log.d("Howard","Fly")}
    }
}
fun test3When(any: Any){
    when(any){
        is String ->{
            Log.d("Howard","我是字串")}
        is Int ->{
            Log.d("Howard","我是整數")}
        else ->{
            Log.d("Howard","Not !!")  }
    }
}
fun test4WhenRange(age:Int){
//    val msg =  when{
//        age>=0 && age <18 ->"未成年"
//        age >= 18&& age <65 ->"成年"
//        age >= 65 && age <300 ->"老年"
//        else -> "生化人!"
//    }
    val msg =  when(age){
         in 0..17 ->"未成年"
         in 18..64 ->"成年"
         in 65..300 ->"老年"
        else -> "生化人!"
    }
    Log.d("Howard",msg)
}
fun test5WhenSeason(month:Int){
   val season =  when(month){
        in 3..5->"春"
        in 6..8->"夏"
        in 9..11->"秋"
        12,1,2 ->"冬"
        else->"你住在火星"
    }
    Log.d("Howard",
        "season:$season")
}

fun test7ForLoop(){
    val n = 7
    for (i in 1 ..n){
        Log.d("Howard","i:$i")
    }
    val range = 1..5
    for (i in range){
        Log.d("Howard","range1 i:$i")
    }
    for (i in range){
        Log.d("Howard","range2 i:$i")
    }
}

fun test8ForLoop(){
    for (n in 1..20 step 4){
        Log.d("Howard","Value:$n")
    }

    for (n in 20 downTo  1 step 2){
        Log.d("Howard","downTo:$n")
    }
}
fun test9ForLoop(){
    for (i in 0 until 5){
        Log.d("Howard","msg:$i")
    }
}
fun testBreakContinue(){
    for (i in 1..10){

        if (i == 6){
            //break
            continue
        }
        Log.d("Howard","i:$i")
    }
}

fun testBreakContinueTag(){

   bye@ for (i in 1 .. 5){
        Log.d("Howard","=================")
        for (k in 1 ..3){
            if ( i ==2){
                break@bye
            }
        Log.d("Howard","$i:$k")
        }
        Log.d("Howard","=================")
    }

}

fun testArray1(){
    val names = arrayOf("Ken","Vivin","Lindy")
    names[1] = "Join"
    names.forEach {
        Log.d("Howard","name:$it")
    }
    for (i in 0 until names.size  ){
        Log.d("Howard","name:${names[i]}")
    }
}
fun testArray2(){
    //限定arrayOf內能新增什麼
    val array0 = arrayOf(30,10,"AA")
    val array = arrayOf<Int>(30,10,17)
    for (n in array){
        Log.d("Howard","number:$n")
    }
}
fun testArray3(){
    val defArray = Array<String>(20){inx->
        "{age:$inx}"
    }
    defArray.forEach {
        Log.d("Howard","json:$it")
    }
}
fun testArray4(){
    //val myArray = arrayOf<Int>(5,6,7)//Array<Int>
   //以下方法需要IntArray
    val myIntArray = intArrayOf(7,9,5,1,3)
    TestArray().foreachIntArray(myIntArray)
    val intArray30 = IntArray(30){-1}
    TestArray().foreachIntArray(intArray30)
    //不建議
    val intArray20 = IntArray(20,{v->-1})
}
fun testArray5(){
    val myIntArray = intArrayOf(7,9,5,1,3)
//    myIntArray.sort()
   // myIntArray.sortDescending()//大到小
    val list = myIntArray.sorted()
    myIntArray.forEach { Log.d("Howard","it:$it") }
    Log.d("Howard","==============")
    list.forEach { Log.d("Howard","list:$it") }
}
