package tw.com.xvpower.firstappkotlin;

public class TestArray {
    public void foreachIntArray(int[] array){
        for (int v : array){
            System.out.println("v:"+v);
        }
    }
}
