package tw.com.xvpower.firstappkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

     fun testMsg():String = "Vivin"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

       btn1.setOnClickListener {
           msgTextView.text = "Hello Ken!!"
       }
      //test1Kotlin()
        // test2When(1)
        /*test3When("Hello")
        test3When(10)
        test3When(10.5)*/
        //test4WhenRange(100)
        //test5WhenSeason(13)
        //test6Enum(Sex.Female)
        //test7ForLoop()
        //test8ForLoop()
       // test9ForLoop()
        //testBreakContinue()
        //testBreakContinueTag()
        //testArray1()
        //testArray2()
        //testArray3()
        //testArray4()
        //testArray5()
       Log.d("Howard","test:${testMsg()}")

        val x = {v:Int->
            Log.d("Howard","v:${v}")
        }
        x(20)
    }
}
