package tw.com.xvpower.ch19_2_dialog;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private String selectMsg = new String();
    private boolean[] selected = {true,true,false};
    private int selectIndex = 2;
    private ImageView imageView;
    private  class MyOnClickListener implements DialogInterface.OnClickListener {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            String msg = "確定";
            switch (which){
                case DialogInterface.BUTTON_POSITIVE:
                    break;
                case DialogInterface.BUTTON_NEGATIVE:
                    msg = "取消";
                    break;
                case DialogInterface.BUTTON_NEUTRAL:
                    msg = "關於我";
                    break;
                default:
                    throw new IllegalArgumentException("Error which");
            }
            Toast.makeText(MainActivity.this,msg,
                            Toast.LENGTH_SHORT).show();
        }
    }

    private class InputOnclickListener  implements DialogInterface.OnClickListener{
        private EditText editText;
            public InputOnclickListener(EditText editText){
            this.editText = editText;
        }
        @Override
        public void onClick(DialogInterface dialog, int which) {

            //AlertDialog myDialog =(AlertDialog) dialog;
            Toast.makeText(MainActivity.this,
                    editText.getText(), Toast.LENGTH_SHORT).show();
//            Log.d("Howard","dialog:"+editText.getText());
        }
    }

    private class SelectClickListener implements DialogInterface.OnMultiChoiceClickListener{
        @Override
        public void onClick(DialogInterface dialog, int index, boolean isChecked) {
            selected[index] = isChecked;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn1 =  findViewById(R.id.btn1);
        Button btn2 =  findViewById(R.id.btn2);
        Button btn3 =  findViewById(R.id.btn3);
        Button btn5 =    findViewById(R.id.btn5);
        Button btn6 = findViewById(R.id.btn6);
        Button btn7 = findViewById(R.id.btn7);
        Button listBtn =   findViewById(R.id.listBtn);
        imageView = findViewById(R.id.imageView);
        MyOnClickListener listener = new MyOnClickListener();
        btn1.setOnClickListener(v->{
            new AlertDialog.Builder(this).
                    setTitle("Title").setMessage("Message").
                    setPositiveButton("確定",listener).
                    setNegativeButton("取消",listener).
                    setNeutralButton("關於我",listener).
                    setCancelable(false).
                    show();
        });
        btn2.setOnClickListener(v->{
            EditText editText = new EditText(this);
            InputOnclickListener listener2 = new InputOnclickListener(editText);
            new AlertDialog.Builder(this).setTitle("Input").
                    setMessage("Msg!!").setView(editText).
                    setPositiveButton("確定",listener2).
                    show();

        });
        btn3.setOnClickListener(v->{
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1,android.R.id.text1,
                    new String[]{"Apple","Banana","Kiwi"});


            //setMessage 與 setAdapter 一同使用
                new AlertDialog.Builder(this).
                        setTitle("Title").
                        setAdapter(arrayAdapter,(d,position)->{
                            selectMsg = arrayAdapter.getItem(position);
                        }).show();
        });
        listBtn.setOnClickListener(v->{

            Toast.makeText(this,selectMsg,Toast.LENGTH_SHORT).show();

        });
        Button btn4 = findViewById(R.id.btn4);
        SelectClickListener selectListener= new SelectClickListener();
        btn4.setOnClickListener(v->{
            String[] array = {"雞腿","雞翅","雞胸"};
            //setMultiChoiceItems不可與setMessage一起使用
            new AlertDialog.Builder(this).
                    setMultiChoiceItems(array,
                            selected,
                            selectListener).
                    setPositiveButton("確定",(d,which)->{
                            StringBuilder sb = new StringBuilder();
                            for (int i =0; i < selected.length;i++){
                                if (selected[i]){
                                    sb.append(array[i]);
                                    sb.append(" ");
                                }
                            }
                        Toast.makeText(this,
                                sb.toString(), Toast.LENGTH_SHORT).show();
                    }).show();
        });
        btn5.setOnClickListener(v->{
            String[] status = {"已婚","未婚","一言難盡"};
            new AlertDialog.Builder(this).
                    setTitle("請選狀態").
                    setSingleChoiceItems(status,
                            selectIndex,(d,index)->{
                                selectIndex = index;
                            }).
                    setPositiveButton("確定",(d,witch)->{
                        Toast.makeText(this,
                                status[selectIndex],Toast.LENGTH_SHORT).show();

                    }).show();

        });
        btn6.setOnClickListener(v->{
            View view = getLayoutInflater().inflate(R.layout.dialog_layout,
                    null,false);
           EditText accountTxt =  view.findViewById(R.id.accountText);
           EditText passwordTxt =  view.findViewById(R.id.passwordTxt);
            new AlertDialog.Builder(this).
                    setTitle("請登入").
                    setView(view).setCancelable(false).
                    setPositiveButton("登入",(d,witch)->{
                       String account =  accountTxt.getText().toString();
                       String password = passwordTxt.getText().toString();
                       Toast.makeText(this,account+":"+password,Toast.LENGTH_SHORT).show();
                    }).
                    setNegativeButton("取消",null).show();
        });
        btn7.setOnClickListener(v->{
            View view = getLayoutInflater().
                    inflate(R.layout.progress_dialog_layout,
                            null,false);
            AlertDialog dialog =   new AlertDialog.Builder(this).
                    setTitle("載入圖片").setView(view).
                    setCancelable(false).show();
           ProgressBar pb = view.findViewById(R.id.progressBar);


            ImageAsyncTask asyncTask = new
                    ImageAsyncTask(dialog,pb,imageView);
            String url = "https://pic.17qq.com/uploads/dpcdkglmdv.jpeg";
            asyncTask.execute(url);


        });


    }
}