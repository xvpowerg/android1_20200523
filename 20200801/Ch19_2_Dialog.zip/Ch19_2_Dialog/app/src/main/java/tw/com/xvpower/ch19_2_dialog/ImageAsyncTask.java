package tw.com.xvpower.ch19_2_dialog;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.appcompat.app.AlertDialog;

public class ImageAsyncTask extends AsyncTask<String,Void, Bitmap> {
   private  AlertDialog dialog;
    private ProgressBar pb;
    private ImageView imageView;
    ImageAsyncTask(AlertDialog dialog,
                   ProgressBar pb,
                   ImageView imageView){
        this.dialog = dialog;
        this.pb = pb;
        this.imageView = imageView;}
    //Execute 之前執行
    //Main Thread
    @Override
    protected void onPreExecute() {
        pb.setVisibility(View.VISIBLE);//顯示ProgressBar
    }
    //其他執行緒
    @Override
    protected Bitmap doInBackground(String... strings) {
        String url =  strings[0];
        Bitmap bitmap =  ImageTool.getImage(url);//下載圖片
        return bitmap;
    }
    //Execute 完成後執行
    //main執行緒
    @Override
    protected void onPostExecute(Bitmap bitmap) {
        if (bitmap != null){
            imageView.setImageBitmap(bitmap);
        }
        pb.setVisibility(View.INVISIBLE);//隱藏ProgressBar
        dialog.dismiss();//關閉AlertDialog
    }
}
