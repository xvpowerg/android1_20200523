package tw.com.xvpower.ch19_2_dialog;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class ImageTool {

    static Bitmap getImage(String url){
        try( InputStream imageStream =  fetch(url)){
             BitmapDrawable bitmapDrawable =
                     (BitmapDrawable)Drawable.createFromStream(imageStream,
                             "src");
                return bitmapDrawable.getBitmap();
        }catch (IOException ex){
            Log.e("Howard","IOException:"+ex);
        }
        return null;
    }

    private  static InputStream fetch(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        InputStream inputStream = (InputStream)url.getContent();
        return inputStream;
    }

}
