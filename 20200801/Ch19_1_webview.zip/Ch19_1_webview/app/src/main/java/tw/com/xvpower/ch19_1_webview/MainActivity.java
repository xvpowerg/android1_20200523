package tw.com.xvpower.ch19_1_webview;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {
    private WebView webView ;
    private Button gotoBtn;
    private ProgressBar bar;

    private class MyWebViewClient extends WebViewClient {
        //開始載入
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            bar.setVisibility(View.VISIBLE);
        }
        //載入完成
        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            bar.setVisibility(View.GONE);
        }
        //回傳 false就不會使用預設瀏覽器開啟網頁 直接使用webView處裡網頁
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return super.shouldOverrideUrlLoading(view, request);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webView);
        gotoBtn = findViewById(R.id.gotoBtn);
        bar = findViewById(R.id.progressBar);
        bar.setVisibility(View.GONE);
        EditText url = findViewById(R.id.urlText);
        //webView.loadUrl("https://www.google.com.tw/");
        //啟動javaScript
        webView.getSettings().setJavaScriptEnabled(true);
        //啟動縮放
        webView.getSettings().setSupportZoom(true);
        //啟動觸控縮放
        webView.getSettings().setBuiltInZoomControls(true);
        MyWebViewClient client = new MyWebViewClient();
        webView.setWebViewClient(client);
        gotoBtn.setOnClickListener(v->{
            webView.loadUrl(url.getText().toString());
        });
    }
}