package tw.com.xvpower.ch2_2_kotlin

class KotlinTeacher:Teacher{
    //呼叫父類別建構子
    constructor(name:String,age:Int):super(name,age)
    //建立預設建構子
    constructor(){
    }
    //建立一個物件幫我用建構子傳入兩個數字
    //物件 方法 可設定運算模式 (+或-或*或/)
    //物件 方法 回傳解果
}