package tw.com.xvpower.ch2_2_kotlin

fun main(vararg  age:String){
    val teacher = Teacher("Vivin",10)
    teacher.print()
    val teacher2 = Teacher("Ken")
    teacher2.print()

    val animal = Animal("Momo",300F)
    animal.height = 350F
    animal.print()
    println()
    val teacher3 = KotlinTeacher()
    teacher3.apply {
        name = "Tom"
        myAge = 10
    }.print()
    val teacher4 = KotlinTeacher("Join",25)
    teacher4.print()

}