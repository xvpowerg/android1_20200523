package tw.com.xvpower.ch2_2_kotlin
//所有Kotlin的類別 預設都final
//類別前加上 open 變為非final
open  class Teacher {
    var name:String = ""
    var myAge:Int = 0
    fun print(){
        println("name:$name age:$myAge")
    }
    constructor(){

    }
    constructor(name:String,myAge:Int = 0){
        this.name = name
        this.myAge = myAge
    }
}