package tw.com.xvpower.ch2_2_kotlin

fun main(vararg  age:String){
    val teacher = Teacher()
    teacher.name = "Join"
    teacher.myAge = 26
    //某些特殊情況下 與外部類別this有所衝突時使用
    //會回傳目前物件
   val obj1 =  teacher.also {
        it.name = "Ken"
        it.myAge =  61
        it.print()
    }
    //自動幫我們在屬性前加上this
    //會回傳目前物件
    val obj2 =  teacher.apply {
        name = "BoBo"
        myAge = 72
        print()
    }

    //let 與 run  與 with 都會回傳最後一行的內容
    val obj4= teacher.let {
        it.name = "Gigi"
        it.myAge = 32
        it.print()
        "Pass"
    }
    teacher.run {

    }

    //回傳最後一行命令的數值
    val obj3 =with(teacher){
        name = "Join"
        myAge = 75
       "Apple"
    }

    println("$obj1 : $obj2 : $obj3")

    println("$obj4 ")


}