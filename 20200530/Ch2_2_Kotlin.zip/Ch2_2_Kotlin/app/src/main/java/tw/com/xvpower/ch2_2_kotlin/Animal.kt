package tw.com.xvpower.ch2_2_kotlin
//在建構子 直接宣告 屬性
class Animal(var name:String, height:Float) {
    var height:Float  = height

    fun print(){
        print("$name : $height cm")
    }
}