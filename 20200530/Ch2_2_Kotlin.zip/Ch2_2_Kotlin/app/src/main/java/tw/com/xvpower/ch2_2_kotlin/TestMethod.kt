package tw.com.xvpower.ch2_2_kotlin
    //kotlin 方法如果沒有定義回傳值 表示回傳Unit
    fun test1(){
        println("test1")
    }
    fun test2(a:Int,b:Int):Int{
        val ans = a*a + b*b
        return ans
    }
fun test2(a:Float,b:Float):Float{
    val ans = a*a + b*b
    return ans
}

    fun initBox(height:Int = 20,width:Int,deep:Int = 10){
        println("$height:$width:$deep")
    }
    fun sum(vararg values:Int):Int{
        var result = 0;
        for (v in values){
            result += v
        }
        return result
    }
fun main(vararg arg:String){
    initBox(20,30)
    initBox(width=50)
    val v = test1()
    val  x = test2(2,3)
    println(v)
    println(x)
    val ans = sum(5,2,3,1)
    println(ans)
    val intArray = intArrayOf(1,2,3)
    //*展開符號
    sum(*intArray)
}