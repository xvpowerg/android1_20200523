package tw.com.xvpower.ch2_1_javabase;

public class Test2 {

    public static void main(String ... args){
        String[] names = {"Ken","Vivin","Lindy"  };
        for (String n : names){
            System.out.print(n+" ");
        }

    }

}
