package tw.com.xvpower.ch2_1_javabase;

//注意 繼承 建構子不會被繼承
//私有的也不會被繼承
public class AndroidStudent extends  Student{
    //如果有給建構子 那麼預設建構子就不會自動建立
    //此建構子為預設建構子
    AndroidStudent(){

    }
    AndroidStudent(String name,int age,float height){
        //super()在建構子表示 呼叫 父類別的建構子
        //super() 只能是第一個命令
        super(name,age,height);
//        this.name = name;
//        this.setAge(age);
//        this.height = height;
    }
}
