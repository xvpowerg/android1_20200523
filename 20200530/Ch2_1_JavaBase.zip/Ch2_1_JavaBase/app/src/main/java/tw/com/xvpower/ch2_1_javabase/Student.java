package tw.com.xvpower.ch2_1_javabase;

public class Student {
    String name;
    private int age;
    float height;
    //Constructor
    //建構式 特性 不須回傳 方法名稱跟類別依樣
    Student(){
    }
    //this 表示目前物件
    Student(String inName,int age,float inHeight){
        name = inName;
        this.setAge(age);
        height =inHeight;
    }
    //存錢
    public void setAge(int age){
        if (age < 10 || age >200){
            System.out.println("錯誤的年齡!");
// return 可回傳數值或離開方法
            //throw new IllegalArgumentException("錯誤的年齡!");
            return;
        }
            this.age = age;


    }
    //領錢
    public int getAge(){
        return age;
    }
    //因為非static所以它屬於物件的方法
    void print(){
       System.out.println(name+":"+age+":"+height);
    }

}
