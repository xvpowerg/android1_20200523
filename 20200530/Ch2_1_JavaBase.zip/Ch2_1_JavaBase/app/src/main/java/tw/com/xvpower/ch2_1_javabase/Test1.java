package tw.com.xvpower.ch2_1_javabase;
public class Test1 {
    /*
    我是測試Java陣列 變數的方法
     */
    static void testJavaBase(){
               int x = 10;
       float e = 2.71828f;
       System.out.println("value:"+x);
       System.out.println("E:"+e);
       String msg = "AB,CD,EF,YU";
       System.out.println(msg);
       String[] strArray = msg.split(",");
       System.out.println(strArray.length);
       System.out.println(strArray[3]);

       for (int i = 0;i< strArray.length;i++){
           System.out.println(i+":"+strArray[i]);
       }

       for (String v : strArray){
           System.out.println(v);
       }

       String[] names = {"Ken","Vivin","Lindy"  };
       for (String n : names){
           System.out.print(n+" ");
       }
       System.out.println("===================");
       String[] values;
       values = new String[]{"Lindy","Join","Lucy"};
        for (String n2 : values){
            System.out.println(n2);
        }
    }
    //void 表示沒有回傳值 不強制return
    //() 表示沒傳參數
    static void test1(){
        System.out.println("test1");
    }
    //static int test2 表示回傳int 那麼就需要強制return
    //(int a,int b) 需要傳2個參數
    static int test2(int a,int b){
        int len =  a*a + b*b;
        return len;
    }
        //...vargs 主要用在當我不知道要傳多少參數時
       // vargs 只能用於方法參數的最後一個
    static int sum(int ... values){
        int result = 0;
        for(int v : values){
            result += v;
        }
        return result;
    }

    //多載 overloading
    //方法名稱要一樣
    //參數的類型或數量不一樣 稱為多載

    static float abs(float f){
        return f < 0? f *-1:f;
    }

    static int abs(int v){
        return v < 0 ? v*-1:v;
    }

    static void initBox(float height ,float width,float deep){
        System.out.println(height+":"+width+":"+deep);
    }
    static void initBox(float height ,float width){
        initBox(height,width,10);
    }
    static void initBox(float height){
        initBox(height,height,height);
    }

    static void testStudent(){
        //Student st 宣告一個可以放 Student的變數
        //new Student() 創造Student 物件
        Student st = new Student("Ken",
                25,186.3f);
        st.setAge(100000);
        System.out.println(st.getAge());
       // st.age=-100000;
//        st.name = "Ken";
//        st.age = 25;
//        st.height = 186.3f;
//希望限制年齡 必須 大於等於10歲 小於等於200歲

        Student st2 = new Student();
        st2.name = "Vivin";
        st2.setAge(30);
        //st2.age = 30;
        st2.height = 175f;
        st.print();
        st2.print();
//        System.out.println(st.name+":"+
//                st.age+":"+st.height);
//
//        System.out.println(st2.name+":"+
//                st2.age+":"+st2.height);
    }
    static void testExtends(){
        AndroidStudent as = new AndroidStudent();
        as.height =182;
        as.name = "Kitty";
        as.setAge(18);
        as.print();
        AndroidStudent as2 = new
                AndroidStudent("Ken",17,165);
        as2.print();
    }
    //static只能呼叫static的
   public static void main(String ... args){
       testExtends();

        //測試Student物件
       //testStudent();

//       initBox(10);
//       initBox(20,50);
//
//
//       testJavaBase();
//       test1();
//       int v = test2(2,3);
//        System.out.println(v);
//        int ans =  sum(1,5,85,2,3);
//        System.out.println(ans);
//        int[] age = {28,31,59,63};
//        sum(age);
//        System.out.println(abs(1.5f));
//       System.out.println(abs(20));
       //System.out.println(abs(-20));

   }

}
