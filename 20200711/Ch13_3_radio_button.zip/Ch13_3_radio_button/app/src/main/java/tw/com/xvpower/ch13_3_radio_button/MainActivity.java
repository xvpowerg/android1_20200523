package tw.com.xvpower.ch13_3_radio_button;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private HashMap<Integer,RadioButton> rbMap = new HashMap<>();
    private String msg = "未選取";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RadioGroup rg =  findViewById(R.id.statusGroup);
        Button btn =   findViewById(R.id.submitBtn);
        rbMap.put(R.id.statusRB1,findViewById(R.id.statusRB1));
        rbMap.put(R.id.statusRB2,findViewById(R.id.statusRB2));
        rbMap.put(R.id.statusRB3,findViewById(R.id.statusRB3));
        rg.setOnCheckedChangeListener((group,id)->{
               RadioButton rb =  rbMap.get(id);
                msg = rb.getText().toString();
        } );

        btn.setOnClickListener(v->{
            Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
        });

    }
}