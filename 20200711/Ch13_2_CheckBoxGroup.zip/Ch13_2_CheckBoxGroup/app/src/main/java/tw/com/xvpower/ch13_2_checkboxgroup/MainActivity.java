package tw.com.xvpower.ch13_2_checkboxgroup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
private ArrayList<CheckBox> checkBoxList = new ArrayList<>();
private int selectCount = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button genCheckBoxBtn =  findViewById(R.id.genCheckBoxBtn);
        Button saveBtn = findViewById(R.id.saveBtn);
       EditText checkboxCount =  findViewById(R.id.checkBoxCount);
      LinearLayout checkBoxGroup =  findViewById(R.id.checkBoxGroup);
      CheckBox checkBoxAll=  findViewById(R.id.checkAll);
//      checkBoxAll.setOnCheckedChangeListener( (b,isChecked)->{
//                for (CheckBox tmCb : checkBoxList){
//                    tmCb.setChecked(isChecked);
//                }
//        });
        checkBoxAll.setOnClickListener(v->{
                if(checkBoxAll.isChecked()){
                    selectCount =checkBoxList.size();
                }else{
                    selectCount = 0;
                }
                for (CheckBox tmCb  : checkBoxList){
                    tmCb.setChecked(checkBoxAll.isChecked());
                }
        });

        genCheckBoxBtn.setOnClickListener(v->{
            //清空其他checkbox
            checkBoxGroup.removeAllViews();
            String countText =  checkboxCount.getText().toString();
            int count =  Integer.parseInt(countText);
            for (int i =1; i <= count;i++){
                CheckBox cbox = new CheckBox(this);
                cbox.setOnClickListener((box)->{
                    boolean selectAll = false;
                    CheckBox tmpCheckBox = (CheckBox)box;
                    if (tmpCheckBox.isChecked()){
                        selectCount++;
                         selectAll = checkBoxList.size() == selectCount;
                    }else{
                        selectCount--;
                    }
                    checkBoxAll.setChecked(selectAll);
                });
                checkBoxList.add(cbox);
                cbox.setText(""+i);
                checkBoxGroup.addView(cbox);
            }
        });

        saveBtn.setOnClickListener(v->{
            StringBuilder sb = new StringBuilder();
            checkBoxList.forEach(c->{
                    if (c.isChecked()){
                        sb.append(c.getText()+" ");
                    }
            });
            Log.d("Howard","Selected:"+sb);
        });


    }
}