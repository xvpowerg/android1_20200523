package tw.com.xvpower.ch13_2_checkboggroup_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.CheckBox
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val checkBoxList = mutableListOf<CheckBox>()
         genCheckBoxBtn.setOnClickListener {

            val count =  checkBoxCount.text.toString().toInt()
            for (i  in 1 .. count){
                val checkBox = CheckBox(this)
                checkBox.text = i.toString()
                checkBoxList.add(checkBox)
                checkBoxGroup.addView(checkBox)
                checkBox.setOnClickListener {
                    var isCheckedAll = false
                    val checkBox = it as CheckBox
                    if (checkBox.isChecked){
                        isCheckedAll =
                                checkBoxList.asSequence().
                                all{cbox->
                                    cbox.isChecked }
                    }
                    checkAll.isChecked = isCheckedAll
                }

            }
        }
        checkAll.setOnClickListener {
            checkBoxList.forEach {box->
                box.isChecked =  checkAll.isChecked
            }
        }

        saveBtn.setOnClickListener {
            //joinToString 把過濾完的內容合併為字串
         val select =   checkBoxList.asSequence().filter {
                it.isChecked }.map {it.text}.joinToString()
            Log.d("Howard","select:$select")
        }



    }
}