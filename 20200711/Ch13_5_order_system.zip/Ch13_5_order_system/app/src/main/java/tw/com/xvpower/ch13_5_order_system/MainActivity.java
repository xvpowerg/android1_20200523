package tw.com.xvpower.ch13_5_order_system;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;

import java.util.ArrayList;
import java.util.HashMap;

import tw.com.xvpower.ch13_5_order_system.view.OrderViewModel;

public class MainActivity extends AppCompatActivity {
    private ArrayList<OrderViewModel> itemList = new ArrayList<>();
    private String categroy = null;
    private void initOrderViewModel(){
        String itemStrFormat = "品名:%s 價格:%d";
        CheckBox boxItem1 =  findViewById(R.id.Item1Box);
        CheckBox boxItem2 =  findViewById(R.id.Item2Box);
        CheckBox boxItem3 = findViewById(R.id.Item3Box);
        EditText item1Count =  findViewById(R.id.Item1Count);
        EditText item2Count = findViewById(R.id.Item2Count);
        EditText item3Count = findViewById(R.id.Item3Count);

        ArrayList<CheckBox> checkboxList = new ArrayList<>();
        checkboxList.add(boxItem1);
        checkboxList.add(boxItem2);
        checkboxList.add(boxItem3);

        ArrayList<EditText>countList = new ArrayList<>();
        countList.add(item1Count);
        countList.add(item2Count);
        countList.add(item3Count);

         int[] prices =  getResources().getIntArray(R.array.price);
         String[] items = getResources().getStringArray(R.array.items);
         for (int i = 0; i < checkboxList.size();i++){
             CheckBox boxItem = checkboxList.get(i);
             EditText countItem =   countList.get(i);
             String boxMsg =   String.format(itemStrFormat,
                     items[i],prices[i]);
             boxItem.setText(boxMsg);

             OrderViewModel ovm= new OrderViewModel();
             ovm.setName(items[i]);
             ovm.setPrice(prices[i]);
             ovm.setCountNumber(countItem);
             ovm.setItemCheckBox(boxItem);
             itemList.add(ovm);
         }


    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initOrderViewModel();
        RadioGroup rg =  findViewById(R.id.categoryGroup);
        Button submitBtn =  findViewById(R.id.submitBtn);
        HashMap<Integer,String> categoryMap = new HashMap<>();
        categoryMap.put(R.id.category1,getString(R.string.category1));
        categoryMap.put(R.id.category2,getString(R.string.category2));

        rg.setOnCheckedChangeListener((g,id)->{
            categroy = categoryMap.get(id);
        });

        submitBtn.setOnClickListener(v->{

            Intent toOrderDetail = new Intent(this,OrderDetailActivity.class);
            startActivity(toOrderDetail);
//            itemList.forEach(vmod->{
//                  if (vmod.isChecked()){
//                      Log.d("Howard","Name:"+vmod.getName());
//                      Log.d("Howard","price:"+vmod.getPrice());
//                      Log.d("Howard","Count:"+vmod.getCount());
//                  }
//            });
//            Log.d("Howard","categroy:"+categroy);
        });


    }
}