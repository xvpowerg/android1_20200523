package tw.com.xvpower.ch13_5_order_system.view;

import android.widget.CheckBox;
import android.widget.EditText;

public class OrderViewModel {
    private CheckBox itemCheckBox;
    private EditText countNumber;
    private String name;
    private int price;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public CheckBox getItemCheckBox() {
        return itemCheckBox;
    }

    public void setItemCheckBox(CheckBox itemCheckBox) {
        this.itemCheckBox = itemCheckBox;
    }

    public EditText getCountNumber() {
        return countNumber;
    }

    public void setCountNumber(EditText countNumber) {
        this.countNumber = countNumber;
    }

    public boolean isChecked(){
        return itemCheckBox!= null &&
                itemCheckBox.isChecked();
    }

    public int getCount(){
        int count = Integer.parseInt(
                this.countNumber.getText().toString());
        return count;
    }
}
