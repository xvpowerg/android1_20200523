package tw.com.xvpower.ch13_4_swichbtn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
          Switch sw1 =  findViewById(R.id.switch1);
          ImageView imageView =  findViewById(R.id.imageView);
        sw1.setOnCheckedChangeListener((sw,isChecked)->{
                if (isChecked){
                    imageView.setVisibility(View.VISIBLE);
                   sw1.setText("關");
                }else{
                    imageView.setVisibility(View.INVISIBLE);
                    sw1.setText("開");
                }

        });
    }
}