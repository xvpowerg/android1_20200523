package tw.com.xvpower.ch13_1_checkbox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
private ArrayList<CheckBox> checkBoxList = new ArrayList<>();
private boolean isChecked = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CheckBox item1 =  findViewById(R.id.itemCheckBox1);
        CheckBox item2 =  findViewById(R.id.itemCheckBox2);
        CheckBox item3 =  findViewById(R.id.itemCheckBox3);
        CheckBox selectAllBox = findViewById(R.id.selectAllBox);
        checkBoxList.add(item1);
        checkBoxList.add(item2);
        checkBoxList.add(item3);
         Button saveBtn = findViewById(R.id.saveBtn);
        selectAllBox.setOnCheckedChangeListener((b,isChecked)->{
               Log.d("Howard","isChecked:"+isChecked);
            checkBoxList.forEach(cb->{
                cb.setChecked(isChecked);
            });
        });
        saveBtn.setOnClickListener(v->{
           isChecked = false;
            StringBuilder sb = new StringBuilder();
            checkBoxList.forEach(cb->{
                if (cb.isChecked()){
                    sb.append(cb.getText().toString()+" ");
                    isChecked = true;
                }
            });
            if (!isChecked){
                Toast.makeText(this,
                        "請選擇一個產品",Toast.LENGTH_SHORT).show();
            }
//            if (item1.isChecked()){
//                sb.append(item1.getText()+" ");
//             }
//            if (item2.isChecked()){
//                sb.append(item2.getText()+" ");
//            }
//            if (item3.isChecked()){
//                sb.append(item3.getText()+" ");
//            }
            Log.d("Howard","msg:"+sb.toString());

        });

    }
}