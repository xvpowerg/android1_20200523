package tw.com.xvpower.ch3_1_oo.override
//class 預設為final
open class Person(open var  name:String,var height:Float) {

//方法預設也是final
open fun printHeight(){
        println("${height} cm")
    }

    override fun toString(): String {
        return "name:$name height:$height"
    }

    override fun equals(other: Any?): Boolean {
        //轉型寫法
       // val v1 = other as Person
        if (other != null && other is Person){
            return this.name == other.name &&
                    this.height == other.height
        }
        return super.equals(other)
    }
}