package tw.com.xvpower.ch3_1_oo.testmethod

fun String.firstAlphabet():String{
    val nameList =  this.split(",")
    var tmp = ""
    for (name in nameList){
        tmp+= "${name[0]} "
    }
    return tmp
}
fun main(vararg  args:String){
    val namesStr = "Ken,Vivin,Tom,Iris"
    print(namesStr.firstAlphabet())
}