package tw.com.xvpower.ch3_1_oo
class Fruit{
    var name:String?
    var price:Int
    constructor(name:String?,price:Int){
        this.name = name
        this.price = price
    }
}
fun main(vararg args:String){
    val f1 = Fruit(null,10)
    //name? 如果name不是null
    //name? 如果name? 是null時 ?: "要回傳取代null的數值"
   val name =  f1.name?.run {
       if(length >5) "錯誤的品名" else this
    }?:"品名空白"
    println(name)

    f1.name!!.let {
        println("!!:${it}")
    }

    f1.name.run {
            if (this!= null){
               val v =  this.length
            }
    }

}