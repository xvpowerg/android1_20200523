package tw.com.xvpower.ch3_1_oo.override

fun main(vararg  args:String){
   val person  = Student("Ken",
       175.2f)
    val person2 = Student("Ken",
        175.2f)
    person.printHeight()
    println(person.name)
    println(person)
    //== 其實是呼叫equals
    println(person == person2)
    //=== 比較是否為相同物件
    println(person === person2)

    val a1 = Animal("LuLu",5,10F);
    val a2 = Animal("LuLu",5,10F);
    println(a1)
    println(a1 == a2)


}