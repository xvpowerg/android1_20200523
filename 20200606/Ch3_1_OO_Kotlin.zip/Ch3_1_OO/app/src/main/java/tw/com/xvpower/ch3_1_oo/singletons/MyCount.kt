package tw.com.xvpower.ch3_1_oo.singletons

object MyCount {
    private var count:Int = 0
    fun add() = count++
    fun printCount() = println("count:$count")
}