package tw.com.xvpower.ch3_1_oo
//Primary Constructor
class Calculate(private val a:Int=0,
                private val b:Int=0) {
    //lateinit 之後再給值
    //有自訂義 set get 那麼無法使用 lateinit
    //set 與 get 成對一定會出現在class 的屬性
     var type:String = ""
     set(value) {
         field = value
         print("type:$value")
     }
     get(){
         return field
     }
//    fun setType(type:String){
//        this.type = type
//    }
    fun result():Number{
        when(type){
           "+" ->{return a +b}
            "-" ->{return a -b}
            "*" ->{return a *b}
            "/" ->{return a /b}
            else ->{return 0}
        }
    }
}