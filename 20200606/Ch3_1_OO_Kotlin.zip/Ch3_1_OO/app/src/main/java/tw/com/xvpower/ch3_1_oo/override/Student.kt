package tw.com.xvpower.ch3_1_oo.override

class Student(name:String,height:Float):
    Person(name,height) {

    override var name: String = ""
        get() = "Student:"+super.name

    override fun printHeight(){
        print("Student:")
        super.printHeight()
    }

}