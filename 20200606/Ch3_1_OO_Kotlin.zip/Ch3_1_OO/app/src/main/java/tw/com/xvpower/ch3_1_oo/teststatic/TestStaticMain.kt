package tw.com.xvpower.ch3_1_oo.teststatic

fun main(vararg args:String){
    val min = MyStatic.min(2,6)
    println(min)
}