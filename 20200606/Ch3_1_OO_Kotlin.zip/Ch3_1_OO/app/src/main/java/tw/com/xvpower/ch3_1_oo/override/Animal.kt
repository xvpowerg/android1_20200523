package tw.com.xvpower.ch3_1_oo.override

data class Animal(val name:String,val age:Int,val height:Float)