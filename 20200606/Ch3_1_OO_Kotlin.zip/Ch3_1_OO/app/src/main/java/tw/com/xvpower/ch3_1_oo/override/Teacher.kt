package tw.com.xvpower.ch3_1_oo.override

class Teacher {
}