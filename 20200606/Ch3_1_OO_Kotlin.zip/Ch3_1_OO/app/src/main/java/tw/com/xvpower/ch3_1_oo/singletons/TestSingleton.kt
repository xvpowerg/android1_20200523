package tw.com.xvpower.ch3_1_oo.singletons

fun main(vararg  args:String){
    MyCount.add()
    MyCount.add()
    MyCount.printCount()
}