package tw.com.xvpower.ch3_1_oo

import tw.com.xvpower.ch3_1_oo.testmethod.firstAlphabet

fun main(vararg args:String){
    val c1 = Calculate(10,2)
    c1.type = "+"
    val vale = c1.type
    println(vale)
    println(c1.result().toFloat())
    val strs = "Apple,Banana,Kewi"
    strs.firstAlphabet()

}