package tw.com.xvpower.ch3_1_oo.teststatic

class MyStatic {
    //靜態用法
    companion object{
        fun  min(a:Int,b:Int):Int{
            return if (a < b) a else b
        }
    }
}