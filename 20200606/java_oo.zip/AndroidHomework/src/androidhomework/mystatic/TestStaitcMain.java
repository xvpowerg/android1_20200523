/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package androidhomework.mystatic;

/**
 *
 * @author xvpow
 */
public class TestStaitcMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	
	TestStatic ts1 = new TestStatic();
	TestStatic ts2 = new TestStatic();
	//非靜態屬物件
	ts1.values = "Value1";
	ts2.values = "Value2";
	//static 屬類別
//	ts1.staticValue = "static Value1";
//	ts2.staticValue = "static Value2";

	TestStatic.staticValue = "static Value1";
	TestStatic.staticValue = "static Value2";
	
	System.out.println(ts1.values);
	System.out.println(ts2.values);
	System.out.println(ts1.staticValue);
	System.out.println(ts2.staticValue);
	
	System.out.println(TestStatic.staticValue);
	System.out.println(TestStatic.staticValue);
	
	System.out.println(TestStatic.max(2, 10));
	
	
    }
    
}
