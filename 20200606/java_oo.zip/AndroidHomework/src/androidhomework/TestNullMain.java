/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package androidhomework;
import java.util.Optional;


class Fruit{
    private String name;
    private int price;
    Fruit(String name,int price){
	this.name = name;
	this.price = price;
    }
    public Optional<String> geName(){
	return Optional.ofNullable(name);
    }
    public int getPrice(){
	return price;
    }
}

public class TestNullMain {
    public static void main(String[] args) {
	// TODO code application logic here
	//ORM
	Fruit f1 = new Fruit("Apple",20);
	//isPresent 表示name不是null
	 if (f1.geName().isPresent()){
	     System.out.println(f1.geName().get());
	 }
    }
    
}
