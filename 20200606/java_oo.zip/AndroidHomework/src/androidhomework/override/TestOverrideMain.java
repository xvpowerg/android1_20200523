/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package androidhomework.override;

/**
 *
 * @author xvpow
 */
public class TestOverrideMain {
    public static void main(String[] args) {
	Person p1 = new Student("Ken",189);
	Person p2 = new Student("Ken",189);
	Person p3 = p2;
	System.out.println(p1.getName());
	System.out.println(p1);
	//==使用在物件時比較物件是否相同
	System.out.println(p1 == p2);
	System.out.println(p3 == p2);
	//equals 比較物件內容是否相同
	//預設情況下跟==是一樣的行為
	System.out.println(p1.equals(p2) );
	System.out.println(p3.equals(p2) );
	
    }
    
}
