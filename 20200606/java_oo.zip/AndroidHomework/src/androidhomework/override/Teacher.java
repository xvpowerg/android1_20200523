/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package androidhomework.override;

/**
 *
 * @author xvpow
 */
public class Teacher extends Person {
     public Teacher(String name,int height){
	super(name,height);//呼叫父類建構子
    }
}
