/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package androidhomework.override;

public class Student extends Person{
    public Student(String name,int height){
	super(name,height);//呼叫父類建構子
    }
    
    public String getName(){
	//super. 呼叫父類別的
	return "Student:"+super.getName();
    }
}
