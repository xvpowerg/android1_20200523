/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package androidhomework.override;

/**
 *
 * @author xvpow
 */
public class Person {
    private String name;
    private int height;
    Person(String name,int height){
	this.name = name;
	this.height = height;
    }
    public String getName(){
	return this.name;
    }
       public int getHeight(){
	return this.height;
    }
       
    public String toString(){
	return this.getName()+":"+this.getHeight();
    }  
    
    public boolean equals(Object obj){
	if (obj == null || obj instanceof Person == false){
	    return false;
	}
	//強制轉型
	Person p1 = (Person)obj;
	return this.getName().equals(p1.getName()) && this.getHeight() == p1.getHeight();
    }
}
