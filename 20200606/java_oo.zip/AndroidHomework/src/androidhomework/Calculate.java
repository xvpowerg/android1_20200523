/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package androidhomework;

/**
 *
 * @author xvpow
 */
public class Calculate {
    private int a,b;
    private String type;
    Calculate(int a,int b){
	this.a = a;
	this.b = b;	
    }
    public void setType(String type){
	this.type = type;
    }
    public Number result(){
	switch(type){
	    case "+":
		return a+b;
	    case "-":
                return a-b;
	    case "*":
		return a*b;
	    case "/":
		return a/b;
	    default:
		return 0;
	}
    }
}
