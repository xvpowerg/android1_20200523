/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package androidhomework.singleton;
public class Connection {
    private int max = 3;
    private int count = 0;
    private static Connection conn;
    private Connection(){
    }
   public static Connection getConnection(){
       if (conn == null){
	   conn = new Connection();
       }
       return conn;
   }    
    public void connect(){
	if (count < max){
	    count++;
	}else{
	    throw new IllegalStateException("連線數量超過:"+max);
	}
    }
    public void cloes(){
	if (count > 0){
	    count--;
	}
    }
}
