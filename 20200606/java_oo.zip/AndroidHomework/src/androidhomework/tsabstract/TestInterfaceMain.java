/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package androidhomework.tsabstract;

/**
 *
 * @author xvpow
 */
public class TestInterfaceMain {

    static void setOnClickListener(OnClickListener listener){
	listener.click();
    }
    public static void main(String[] args) {
	setOnClickListener(new OnClickListener(){	   
	    public void click(){
		System.out.println("click:!!!");
	    }
	});
	
    }
    
}
