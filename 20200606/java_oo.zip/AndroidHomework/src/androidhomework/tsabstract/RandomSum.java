/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package androidhomework.tsabstract;
import java.util.Random;
public class RandomSum extends Sum {
    public  int[] genNumbers(){
	Random ran = new Random();
	  int[] array = new int[10];
	    for (int i = 0;i<array.length;i++){
		array[i] = ran.nextInt(100);
	    }
	  return array;
     }
}
