/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package androidhomework.tsabstract;

/**
 *
 * @author xvpow
 */
public class TestAbstractMain {
    public static void main(String[] args) {
	Sum rSrm = new RandomSum();
	System.out.println(rSrm.sum());
	//匿名內部類
	Sum sum2 = new Sum(){
	    public int[] genNumbers(){
		return new int[]{2,6,8,1};
	    }
	};
	System.out.println(sum2.sum());
    }
}
