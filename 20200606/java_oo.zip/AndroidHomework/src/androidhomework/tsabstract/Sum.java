/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package androidhomework.tsabstract;

/**
 *
 * @author xvpow
 */
//abstract 有些方法目前知道如何做
//有些方法在使用此抽象類開發時才知道如何做
//abstract 類別不可new
public abstract class Sum {
    public Number sum(){
	int result = 0;
	for (int v : genNumbers()){
	    result += v;
	}
	return result;
    }
    public abstract int[] genNumbers();
}
