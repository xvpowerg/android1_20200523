package tw.com.xvpower.ch23_fragment_tranaction;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
        private Fragment fragmentA,fragmentB,fragmentC;

       private void onClick(View view){
           fragmentA = new FragmentA();
           fragmentB = new FragmentB();
           fragmentC = new FragmentC();
         FragmentTransaction ft =
                 getSupportFragmentManager().beginTransaction();
           Log.d("Howard","Test Fragment!");
            switch(view.getId()){
                case R.id.pageBtn1:
                    Log.d("Howard","pageBtn1!");
                    //如果目前container沒有Fragment就作Add
                    // 如有fragment 就作覆蓋的動作
                    ft.replace(R.id.fragment_container,fragmentA).
                            addToBackStack("fragmentGroup");
                    ft.commit();
                    break;
                case R.id.pageBtn2:
                    ft.replace(R.id.fragment_container,fragmentB).
                            addToBackStack("fragmentGroup");
                    ft.commit();
                    break;
                case R.id.pageBtn3:
                    ft.replace(R.id.fragment_container,fragmentC).
                            addToBackStack("fragmentGroup");;
                    ft.commit();
                    break;

            }
       }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b1 = findViewById(R.id.pageBtn1);
        Button b2 = findViewById(R.id.pageBtn2);
        Button b3 = findViewById(R.id.pageBtn3);

        b1.setOnClickListener(this::onClick);
        b2.setOnClickListener(this::onClick);
        b3.setOnClickListener(this::onClick);
    }
}