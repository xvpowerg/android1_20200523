package tw.com.xvpower.test_fragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    interface ChangeImage{
        void change(ImageView view);
    }

    private ImageView imageView;
    private ImageFragment imageFragment;
    private  View.OnClickListener onclick = (View view)->{
        int res = R.drawable.image1;
            switch(view.getId()){
                case R.id.image1Btn2:
                    res = R.drawable.image1;
                    break;
                case R.id.image2Btn2:
                    res = R.drawable.image2;
                    break;
                case R.id.image3Btn2:
                    res = R.drawable.image3;
                    break;
            }
            Log.d("Howard","res:"+res);
         int finalRes = res;
        imageFragment.changeImage((imageview)->{
            imageview.setImageResource(finalRes);
        });
       // imageView.setImageResource(res);
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);
        ButtonsFragment btnFragment =
                (ButtonsFragment)getSupportFragmentManager().
                        findFragmentById(R.id.btnFragment);
         imageFragment =
                (ImageFragment)getSupportFragmentManager().
                        findFragmentById(R.id.imageFragment);

        btnFragment.initBtnOnclick(onclick);
        //imageFragment.changeImage();

//       Button btn1 =  findViewById(R.id.image1Btn);
//        Button btn2 =  findViewById(R.id.image2Btn);
//        Button btn3 =  findViewById(R.id.image3Btn);
//        imageView = findViewById(R.id.imageView);
//
//        btn1.setOnClickListener(onclick);
//        btn2.setOnClickListener(onclick);
//        btn3.setOnClickListener(onclick);
    }
}