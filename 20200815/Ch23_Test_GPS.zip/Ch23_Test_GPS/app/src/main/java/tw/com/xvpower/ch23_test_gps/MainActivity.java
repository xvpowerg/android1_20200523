package tw.com.xvpower.ch23_test_gps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;

import tw.com.xvpower.ch23_test_gps.model.LocationModel;

public class MainActivity extends AppCompatActivity {
    private LocationModel lm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LocationManager locationManager =
                (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        lm = new LocationModel(locationManager);
    }

    private void checkGSPPermission(){
        ActivityCompat.requestPermissions(this,new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
        },100);
    }

    private void addLocationChangeListener(){

        if (lm.isProviderEnabled() == false){
            Intent opGps =
                    new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(opGps);
            return;
        }

        lm.addListener();
        lm.setChangedEven((lat,lot)->{
            Log.d("Howard",lat+":"+lot);
        });
    }

    private void initGSPPermission(){
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            || ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                addLocationChangeListener();
            }else{
                checkGSPPermission();
            }


    }

    @Override
    protected void onResume() {
        super.onResume();
        initGSPPermission();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
       if (grantResults[0]  == PackageManager.PERMISSION_GRANTED ||
           grantResults[1] == PackageManager.PERMISSION_GRANTED){
           addLocationChangeListener();
       }
    }

    @Override
    protected void onPause() {
        super.onPause();
        lm.removeListener();
    }
}