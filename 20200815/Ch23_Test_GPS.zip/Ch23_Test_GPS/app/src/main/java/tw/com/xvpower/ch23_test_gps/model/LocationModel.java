package tw.com.xvpower.ch23_test_gps.model;


import android.annotation.SuppressLint;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

public class LocationModel {

     public static interface LocationChangedEven{
         void change(double latitude,double longitude);
     }

    private LocationChangedEven changedEven;
    private MyLocationListener myLocation;
    private LocationManager locationManager;
    private class MyLocationListener implements LocationListener {

        @Override
        public void onLocationChanged(Location location) {
            double latitude = location.getLatitude();//緯度
            double longitude =  location.getLongitude();//經度
            if (changedEven!= null){
                changedEven.change(latitude,longitude);
            }
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    }



    public LocationModel(LocationManager locationManager){
        this.locationManager = locationManager;
        myLocation = new MyLocationListener();

    }

    public void setChangedEven(LocationChangedEven changedEven ){
            this.changedEven = changedEven;
    }
    @SuppressLint("MissingPermission")
    public void addListener(){
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                5000L,0f,myLocation);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                5000L,0f,myLocation);
    }

    public void removeListener(){
        locationManager.removeUpdates(myLocation);
    }

    public boolean isProviderEnabled(){
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
         || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }





}
