package tw.com.xvpower.ch23_google_map;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        Button btn1 =  findViewById(R.id.mapBtn1);
        btn1.setOnClickListener((v)->{
            MarkerOptions mo = new MarkerOptions();
            LatLng latLng = new LatLng(25.102067, 121.548821);
            mMap.addMarker(mo.position(latLng));
            //會移動到定位點
            //mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            //17f zoom  最大到 21 深度
            //2000 2秒移動速度
            //Zoom 後會呼叫 CancelableCallback
            mMap.animateCamera(
                    CameraUpdateFactory.newLatLngZoom(latLng,21f),
                    2000,null);
        });


        Button btn2 =  findViewById(R.id.mapBtn2);
        btn2.setOnClickListener(v->{

            //建立一個不同顏色的Mark
            BitmapDescriptor bd =
                    BitmapDescriptorFactory.
                            defaultMarker(BitmapDescriptorFactory.HUE_BLUE);
                //22.046027, 120.698959
            LatLng latLng  = new LatLng(22.046027, 120.698959);
            MarkerOptions mark = new MarkerOptions();
            mark.position(latLng);
            mark.title("國立海洋生物博物館");
            mark.icon(bd);
            mMap.addMarker(mark);
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,
                                17));
            //GoogleMap.MAP_TYPE_HYBRID 出現衛星地圖與街道名稱
            //GoogleMap.MAP_TYPE_NONE  地圖上什麼都沒有
            //GoogleMap.MAP_TYPE_NORMAL 一般預設
            //GoogleMap.MAP_TYPE_SATELLITE 只有衛星圖
            //GoogleMap.MAP_TYPE_TERRAIN 會有地形

            mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        });
    }

@SuppressLint("MissingPermission")
private void myLocationEnabled(){
    mMap.setMyLocationEnabled(true);
}

    private void enableMyLocation(){
        //ACCESS_FINE_LOCATION 衛星定位模式
        //ACCESS_COARSE_LOCATION 使用wifi定位
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        ||ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            myLocationEnabled();
        }else{
            ActivityCompat.requestPermissions(this,new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION},
                    100);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
//        Log.d("Howard","grantResults[1]:"+
//                (grantResults[1] == PackageManager.PERMISSION_GRANTED));
        //grantResults陣列的數量跟requestPermissions 陣列有關
        if (grantResults[0] == PackageManager.PERMISSION_GRANTED ||
                grantResults[1] ==  PackageManager.PERMISSION_GRANTED){
            myLocationEnabled();
        }
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        UiSettings uiSet =  mMap.getUiSettings();
        //放大縮小按鈕
        uiSet.setZoomControlsEnabled(true);
        //可開啟或關閉傾斜手勢 預設為開啟
        uiSet.setTiltGesturesEnabled(true);
        enableMyLocation();
    }
}