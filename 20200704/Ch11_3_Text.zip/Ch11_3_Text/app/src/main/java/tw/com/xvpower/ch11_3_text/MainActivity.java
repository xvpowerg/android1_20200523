package tw.com.xvpower.ch11_3_text;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    public void imageBtnClick(View view){
        Toast.makeText(this,"Toast imageBtnClick!!!",Toast.LENGTH_LONG).show();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_button_layout);
            Button btn1 = findViewById(R.id.mybtn1);
       ImageView imageView =  findViewById(R.id.imageView);
        btn1.setOnLongClickListener(v->{
            Log.d("Howard","LongClickListener!!");
          return false;
        });

     ToggleButton togbtn =  findViewById(R.id.toggleButton3);
        togbtn.setOnCheckedChangeListener((toggleBtn,isCheck)->{
                if (isCheck){
                    imageView.setVisibility(View.VISIBLE);
                }else{
                    imageView.setVisibility(View.GONE);
                }
            Log.d("Howard","isCheck:"+isCheck);
        });

        Switch switchBtn = findViewById(R.id.switch4);
        switchBtn.setOnCheckedChangeListener((btn,isCheck)->{
                    if (isCheck){
                        Toast.makeText(this,switchBtn.getTextOn(),
                                Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(this,switchBtn.getTextOff(),
                                Toast.LENGTH_SHORT).show();
                    }

        });
    }
}