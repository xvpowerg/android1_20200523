package tw.com.xvpower.ch11_tr_animation_kotlin

import android.os.Bundle
import android.transition.Explode
import android.transition.Fade
import android.transition.Slide
import android.transition.Transition
import android.util.Log
import android.view.Window
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.detail_layout.*

class DetailActivity : AppCompatActivity() {
    private lateinit var infos:Array<String>
    private val images = intArrayOf(R.drawable.image1,
        R.drawable.image2,
        R.drawable.image3,R.drawable.image4)
    private fun setupTransition(){
        //一定要呼叫window.requestFeature
        window.requestFeature(Window.FEATURE_CONTENT_TRANSITIONS)
        var transition: Transition = Explode()
        when(intent.getStringExtra("flag")){
            "explode" ->{
                val explodeTransition = Explode()
                explodeTransition.duration = 1000
                transition= explodeTransition
            }
            "slide" ->{
                val slide = Slide()
                slide.duration = 1000
                transition= slide
            }
            "fade"->{
                val fade = Fade()
                fade.duration = 1000
                transition = fade
            }
        }
        window.enterTransition = transition
        window.exitTransition = transition
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //一定要在setContentView之前呼叫setupTransition
        setupTransition()
        setContentView(R.layout.detail_layout)
        infos = resources.getStringArray(R.array.detail)
       val type =   intent.getIntExtra("type",-1)
        infoText.text = infos[type]
        roleImageView.setImageResource(images[type])
    }
}