package tw.com.xvpower.ch11_tr_animation_kotlin

import android.app.ActivityOptions
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import android.util.Pair
class MainActivity : AppCompatActivity() {
        private fun showDetail(btn: View,flag:String=""){
            val intent = Intent(this,
                DetailActivity::class.java)
                var type = -1;
                val imagePair:Pair<View,String> =
                    Pair(titleImageView,getString(R.string.imageTransition))
             val textPair:Pair<View,String> =
                            Pair(btn,getString(R.string.textTransition))
               val tranAnimatOption =  ActivityOptions.makeSceneTransitionAnimation(this,
                                                    imagePair,textPair)
            when(btn.id){
                R.id.roleBtn1 -> type = 0
                R.id.roleBtn2 -> type = 1
                R.id.roleBtn3 -> type = 2
                R.id.roleBtn4 -> type = 3
            }
            intent.putExtra("type",type)
            intent.putExtra("flag",flag)
            startActivity(intent,tranAnimatOption.toBundle())
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        roleBtn1.setOnClickListener {showDetail(it)}
        roleBtn2.setOnClickListener {showDetail(it,"explode")}
        roleBtn3.setOnClickListener {showDetail(it,"slide")}
        roleBtn4.setOnClickListener {showDetail(it,"fade")}
    }
}