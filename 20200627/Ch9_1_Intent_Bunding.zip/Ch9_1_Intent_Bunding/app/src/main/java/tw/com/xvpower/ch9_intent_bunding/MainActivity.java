package tw.com.xvpower.ch9_intent_bunding;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         Button caluBMI =  findViewById(R.id.caluBMI);
        EditText heightEdt = findViewById(R.id.heightEdit);
        EditText weightEdt = findViewById(R.id.weightEdit);
        caluBMI.setOnClickListener(v->{
             String heightStr = heightEdt.getText().toString();
             String weightStr = weightEdt.getText().toString();
             Log.d("Howard",heightStr+":"+weightStr);
            Intent startIntent = new Intent(this,
                    BmiActivity.class);
            startIntent.putExtra("heightStr",heightStr);
            startIntent.putExtra("weightStr",weightStr);
            startActivity(startIntent);
        });
    }
}