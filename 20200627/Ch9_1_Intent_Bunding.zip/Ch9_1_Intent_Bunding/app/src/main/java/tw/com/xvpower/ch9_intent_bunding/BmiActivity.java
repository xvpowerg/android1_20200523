package tw.com.xvpower.ch9_intent_bunding;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import tw.com.xvpower.ch9_intent_bunding.model.BmiBaseInfo;

public class BmiActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bmi_layout);
        Intent data = getIntent();
        String heightStr = data.getStringExtra("heightStr");
        String weightStr = data.getStringExtra("weightStr");
        Log.d("Howard",heightStr+":"+weightStr);
        try{
            BmiBaseInfo bmiBaseInfo =
                    new BmiBaseInfo(this,heightStr,weightStr);
            TextView tv =  findViewById(R.id.bmiMsgTxt);
            tv.setText(bmiBaseInfo.getBmiStr());
            TextView statusTxt =  findViewById(R.id.statusTxt);
            statusTxt.setText(bmiBaseInfo.getBmiStatusDetail());
        }catch(Exception ex){
            Toast.makeText(this,ex.getMessage(),Toast.LENGTH_LONG).show();
        }

    }
}
