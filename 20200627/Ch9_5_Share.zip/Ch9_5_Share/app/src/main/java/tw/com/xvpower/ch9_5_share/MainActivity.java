package tw.com.xvpower.ch9_5_share;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import tw.com.xvpower.ch9_5_share.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityMainBinding ab =  ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(ab.getRoot());
        ab.sendMsgBtn.setOnClickListener(v->{
            String msg = ab.textMsgEdit.getText().toString();
            Intent sendTextIntent = new Intent();
            sendTextIntent.setAction(Intent.ACTION_SEND);
            sendTextIntent.putExtra(Intent.EXTRA_TEXT,msg);
            sendTextIntent.setType("text/plain");
            startActivity(Intent.createChooser(sendTextIntent,"請選要分享文字的對象"));
        });
        ab.shareImageBtn.setOnClickListener(v->{
            Intent shareImageIntent = new Intent();
            Uri uri = Uri.parse("android.resource://"+
                    getApplicationContext().getPackageName()+"/"+
                    R.drawable.image2);
            shareImageIntent.setAction(Intent.ACTION_SEND);
            shareImageIntent.putExtra(Intent.EXTRA_STREAM,uri);
            shareImageIntent.setType("image/*");
            startActivity(Intent.createChooser(shareImageIntent ,"請選擇要分享圖片的對象"));
        });
        //可開啟圖庫
        ab.openGallery.setOnClickListener(v->{
                Intent intent = new Intent();
                intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(intent,100);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100){
            Uri uri = data.getData();
            Intent shareImageIntent = new Intent();
            shareImageIntent.setAction(Intent.ACTION_SEND);
            shareImageIntent.putExtra(Intent.EXTRA_STREAM,uri);
            shareImageIntent.setType("image/*");
            startActivity(Intent.createChooser(shareImageIntent ,
                    "請選擇要分享圖片的對象"));
        }
    }
}