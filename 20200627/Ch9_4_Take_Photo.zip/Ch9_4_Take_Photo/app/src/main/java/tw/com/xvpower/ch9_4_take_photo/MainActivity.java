package tw.com.xvpower.ch9_4_take_photo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import tw.com.xvpower.ch9_4_take_photo.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding ab;
    private   Bitmap bmp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("Howard","onCreate savedInstanceState:"+savedInstanceState);
         ab = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(ab.getRoot());
        ab.takeBtn.setOnClickListener(v -> {
            Intent it = new
                    Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(it,100);
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Howard","onStart");

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Howard","onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Howard","onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("Howard","onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy");
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.d("Howard","onRestoreInstanceState");
        bmp = (Bitmap) savedInstanceState.get("bitmp");
        if (bmp != null){
            ab.imageView.setImageBitmap(bmp);
        }

    }
    //當可能目前的資源被系統移除時
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d("Howard","onSaveInstanceState");
        outState.putParcelable("bitmp",bmp);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && data!= null){
            bmp = (Bitmap) data.getExtras().get("data");
            ab.imageView.setImageBitmap(bmp);
        }
    }
}