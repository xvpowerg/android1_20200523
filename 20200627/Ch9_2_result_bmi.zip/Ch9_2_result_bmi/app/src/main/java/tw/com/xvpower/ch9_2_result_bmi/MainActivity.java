package tw.com.xvpower.ch9_2_result_bmi;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button caluBmiBtn =  findViewById(R.id.caluBMI);
        EditText hEdit = findViewById(R.id.heightEdit);
        EditText wEdit = findViewById(R.id.weightEdit);
        caluBmiBtn.setOnClickListener(v->{
            String hStr = hEdit.getText().toString();
            String wStr = wEdit.getText().toString();
            Intent argsIntent = new Intent(this,
                    CalculateBmiActivity.class);
            argsIntent.putExtra("height",hStr);
            argsIntent.putExtra("weight",wStr);
            startActivityForResult(argsIntent,250);
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) return;
        switch (requestCode){
            case 250:
                Log.d("Howard","bmi:"+
                        data.getStringExtra("bmi_result"));
                break;
        }
        Log.d("Howard:","requestCode:"+requestCode);
        Log.d("Howard:","resultCode:"+resultCode);
    }
}