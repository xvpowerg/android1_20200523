package tw.com.xvpower.ch9_2_result_bmi;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import tw.com.xvpower.ch9_2_result_bmi.model.BmiBaseInfo;

public class CalculateBmiActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         Intent data = getIntent();
        String height = data.getStringExtra("height");
        String weight =  data.getStringExtra("weight");
        Log.d("Howard",height+":"+weight);
        BmiBaseInfo bmiInfo = new BmiBaseInfo(this,height,weight);
        String bmi = bmiInfo.getBmiStr();
        Log.d("Howard","bmi:"+bmi);

        Intent intent = new Intent();
        intent.putExtra("bmi_result",bmi);
        setResult( RESULT_OK,intent);
        finish();

    }
}
