package tw.com.xvpower.ch9_2_result_bmi.model;

import android.content.Context;
import android.util.Log;

import tw.com.xvpower.ch9_2_result_bmi.R;

public class BmiBaseInfo {
    private double height;
    private double weight;
    private double bmi;
    private Context context;
    public BmiBaseInfo(Context context, String heightStr, String weightStr){
            if (heightStr == null || heightStr.isEmpty()){
                throw new IllegalArgumentException("錯誤的身高");
            }
        if (weightStr == null || weightStr.isEmpty()){
            throw new IllegalArgumentException("錯誤的體重");
        }
           double height =  Double.parseDouble(heightStr);
           double weight =  Double.parseDouble(weightStr);
        setHeightAndWeight(context,height,weight);
    }

    public BmiBaseInfo(Context context, double height, double weight){
        setHeightAndWeight(context,height,weight);
    }
    private void setHeightAndWeight(Context context,double height,double weight){
        if (height == 0 || weight == 0){
            throw new IllegalArgumentException("身高或體重不可為0");
        }
        this.height = height;
        this.weight = weight;
        this.bmi = calculateBmi(height,weight);
        this.context = context;
    }

    public String getBmiStatus(){
        //BMI <20 偏低
        //BMI >=20 && BMI<26正常
        //BMI >=26 && BMI<30　偏高
        //BMI >=30 && BMI<40　過高
        //BMI >= 40 危險
        String msg =context.getString(R.string.bmi_status_danger);
        Log.d("Howard","bmi:"+bmi);
        if (bmi <20){
            msg =context.getString(R.string.bmi_status_low);
        }else if(bmi <26){
            msg =context.getString(R.string.bmi_status_normal);
        }else if(bmi <30){
            msg =context.getString(R.string.bmi_status_height);
        }else if(bmi <40){
            msg =context.getString(R.string.bmi_status_too_height);
        }
        return msg;

    }
    public static double calculateBmi(double height,double weight){
        double bmi = weight / Math.pow((height / 100),2);
        return bmi;
    }
    public String getBmiStr(){
        return String.format("%.2f",bmi);
    }
    public String getBmiStatusDetail(){
        return String.format("身高:%.2f%n 體重:%.2f%n 狀態:%s",
                height,weight,getBmiStatus());
    }










}
