package tw.com.xvpower.ch9_3_call;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
   private EditText phoneNumberTxt =null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = findViewById(R.id.calloutBtn);
        phoneNumberTxt = findViewById(R.id.phoneNumerTxt);
        btn.setOnClickListener(v -> {
            String phoneNumber =
                    phoneNumberTxt.getText().toString();
            Uri uri = Uri.parse("tel:" + phoneNumber);
            Intent intent = new Intent(Intent.ACTION_CALL, uri);
            if (ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.CALL_PHONE) !=
                    PackageManager.PERMISSION_GRANTED) {
                Log.d("Howard","CALL_PHONE!!!");
                //跳出授權頁面
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.CALL_PHONE},
                        100);
                return;
            }
            startActivity(intent);
        });
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
         if (requestCode == 100 && grantResults.length >0 &&
                 grantResults[0] == PackageManager.PERMISSION_GRANTED){
             String phoneNumber =
                     phoneNumberTxt.getText().toString();
             Uri uri = Uri.parse("tel:" + phoneNumber);
             Intent intent = new Intent(Intent.ACTION_CALL, uri);
             startActivity(intent);
         }
    }
}