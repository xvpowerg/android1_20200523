package tw.com.xvpower.ch4_4_createactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {
    String activtiyName = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("Howard",activtiyName+" onCreate");
        Button btn =  findViewById(R.id.toActivtiyBtn);
        btn.setOnClickListener(v->{
            Intent toActivity = new Intent(this,
                    SecondActivity.class);
            //切換Activity
            startActivity(toActivity);

        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("Howard",activtiyName+" onRestart");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Howard",activtiyName+" onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Howard",activtiyName+" onResume");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("Howard",activtiyName+" onStop");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Howard",activtiyName+" onPause");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Howard",activtiyName+" onDestroy");
    }
}