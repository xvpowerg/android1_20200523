package tw.com.xvpower.ch4_4_createactivity;


import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Activity3  extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activtiy3_layout);
        Button backBtn =  findViewById(R.id.backBtn);
        backBtn.setOnClickListener(v->{
                finish();
        });
    }
}
