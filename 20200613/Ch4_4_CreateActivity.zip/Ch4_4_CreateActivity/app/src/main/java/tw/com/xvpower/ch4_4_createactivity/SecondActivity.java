package tw.com.xvpower.ch4_4_createactivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity  extends AppCompatActivity {
    String activtiyName = "SecondActivity";
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("Howard",activtiyName+" onCreate");
        setContentView(R.layout.second_layout);
        Button nextBtn =  findViewById(R.id.nextBtn);
        nextBtn.setOnClickListener((v)->{
            Intent toActivity = new Intent(this,
                    Activity3.class);
            startActivity(toActivity);
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("Howard",activtiyName+" onRestart");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Howard",activtiyName+" onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Howard",activtiyName+" onResume");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("Howard",activtiyName+" onStop");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Howard",activtiyName+" onPause");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Howard",activtiyName+" onDestroy");
    }
}
