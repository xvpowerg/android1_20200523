package tw.com.xvpower.ch4_2_activitylifecycle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("Howard","onCreate!");
        //init 初始化 找元件
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("Howard","onRestart!");
        //做一些onStart 前置動作
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Howard","onStart!");
        //可顯示UI但是無法控制
        //排版配置 載入圖片 跟畫面相關的
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Howard","onResume!");
        //GPS 的Listener
        //Bluetooth 的Listener
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Howard","onPause!");
        //移除 GPS 的Listener
        //移除 Bluetooth 的Listener
        //快速存放一些暫存
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("Howard","onStop!");
        //移除 圖片資源
        //移除 UI畫面設定
        //把一些重要資訊寫入本機資料庫或雲端
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy!");
        //其他未釋放的資源 做釋放的動作
    }
}