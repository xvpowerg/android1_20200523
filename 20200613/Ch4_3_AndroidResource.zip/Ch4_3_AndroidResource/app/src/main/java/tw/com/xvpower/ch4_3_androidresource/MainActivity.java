package tw.com.xvpower.ch4_3_androidresource;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button saveBtn =  findViewById(R.id.saveBtn);
        saveBtn.setOnClickListener((v)->{
            String saveMsg = getString(R.string.sava_complete);
            Toast.makeText(this,saveMsg,Toast.LENGTH_SHORT).show();
        });
    }
}