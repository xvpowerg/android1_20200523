package tw.com.xvpower.ch4_1_lambda_and_oo

interface OnClickListener {
    fun onClick();
}