package tw.com.xvpower.ch4_1_lambda_and_oo



class MyClick:OnClickListener{
    override fun onClick() {
        println("onClick!!!")
    }
}
fun setOnClick(onClickLister:OnClickListener){
    onClickLister.onClick()
}
fun setOnClick(onclick:()->Unit){
    onclick()
}
fun main(vararg  args:String){
    val myClick1 = MyClick()
    myClick1.onClick()

    //kotlin 匿名內部類寫法
    setOnClick(object : OnClickListener{
        override fun onClick() {
            println("onClick!!!!...")
        }
    })

    setOnClick{
        println("onClick lambda!!")
    }
}