package tw.com.xvpower.ch4_1_lambda_and_oo

fun main(vararg  args:String){
    //預設的List是不可修改的
        val list = listOf("Ken","Vivin","Lindy")
          println(list.javaClass)
          println(list[0])
       for (v in list){
            println(v)
       }
    val mList = mutableListOf<String>("Apple","Banana","Kiwi")
    println(mList.javaClass)
    mList.add("Tomato")
    mList.forEach {x->
        println(x)
    }


    println("=============Set================")
    val set = setOf(10,50,70,29,50,70,10)
    println(set.javaClass)
    set.forEach { print("$it ") }
    println()
    println("==========mutableSet=======================")
    val mSet = mutableSetOf<Int>(70,20,10,11,13)
    mSet.add(15)
    mSet.forEach { print("$it ") }
    println()
    println("=============Map================")
    val map = mapOf("green" to 0x00BF01,"red" to 0xBB0011,"blue" to 0x0011AA)
    println(map.javaClass)
    map.forEach { t, u ->
            println("$t:$u")
    }
    val map2 = mutableMapOf(10 to "IPad", 5 to "iPhone",15 to "PS5")
    println(map2.javaClass)
    map2[11] = "xBox"
    map2.forEach { t, u ->
        println("$t:$u")
    }
}