package tw.com.xvpower.ch4_1_lambda_and_oo

fun test1(x:Int,y:Int,function:(Int,Int)->Int){
    println(function(x,y))
}
fun test2(x:Float,y:Float,i:Int,k:Int,
          function1: (Float, Float) -> Float,
          function2:(Int,Int)->Int){
    println(function1(x,y))
    println(function2(i,k))
}
fun main(vararg age:String){
    test1(50,30){x,y->
        if(x > y) x else y
    }
    test2(52F,20F,11,30,{x,y->x+y}){i,k->i-k}
}