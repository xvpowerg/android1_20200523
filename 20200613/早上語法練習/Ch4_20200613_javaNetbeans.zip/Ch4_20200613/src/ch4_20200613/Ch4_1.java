/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200613;
import java.util.Random;
public class Ch4_1 {
    public static void setOnTouch(OnTouch touch){
	Random random = new Random();
	 float x = random.nextFloat()*10;
	 float y = random.nextFloat()*10;
	float rate = touch.touching(x, y);
	System.out.println("rate:"+rate);
    }
    private static float touchAction(float x,float y){
	System.out.println(x+":"+y);
	return y / x;
    }
    public static void main(String[] args) {
	setOnTouch(new OnTouch(){
	    public float touching(float x,float y){
		System.out.println("Ref.."+x+":"+y);
		return y / x;
	    }
	});
	//setOnTouch();
	//實作介面 
	//需求是 印出 x 與 y
	//回傳 一個float 0
	//java 8 提出lambda
	setOnTouch((piX,piY)->{
	    System.out.println(piX+":"+piY);
	    return piX/piY;
	});
	//Method Reference
	setOnTouch(Ch4_1::touchAction);
	
    }
    
}

