/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200613;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.HashMap;
import java.util.Map.Entry;
public class Ch4_2 {

    public static void main(String[] args) {
	ArrayList<String> list = new ArrayList<>();
	list.add("Ken");
	list.add("Vivin");
	list.add("Join");
	for (String v : list){
	    System.out.println(v);
	}
	list.remove("Vivin");
	System.out.println("======================");
	for (String v : list){
	    System.out.println(v);
	}
	System.out.println("==========Set===========");
	//可過濾重複
	HashSet<Integer> hashSet = new HashSet<>();
	hashSet.add(20);
	hashSet.add(10);
	hashSet.add(30);
	hashSet.add(10);
	for (int v : hashSet){
	    System.out.println(v);
	}
	
	System.out.println("==========Map===========");
	HashMap<String,Integer> map = new HashMap<>();
	map.put("Join",10 );
	map.put("Ken",5 );
	map.put("Lucy",9 );
	map.put("Ken",6 );
       Set<Entry<String,Integer>> entrySet = map.entrySet();
       for (Entry en :entrySet){
	   System.out.println(en.getKey()+":"+en.getValue());
       }
    }
    
}
