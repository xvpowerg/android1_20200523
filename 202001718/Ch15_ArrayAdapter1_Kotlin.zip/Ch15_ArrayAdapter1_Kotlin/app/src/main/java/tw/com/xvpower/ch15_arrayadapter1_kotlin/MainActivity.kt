package tw.com.xvpower.ch15_arrayadapter1_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.core.view.get
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    private val regionArray = intArrayOf(R.array.region_0,
                                        R.array.region_1,
                                        R.array.region_2)
    private lateinit var regionMap:Map<Int,Array<String>>

    fun initRegionMap(){
        regionMap = regionArray.mapIndexed {
                index, regionArrayId -> index to resources.getStringArray(regionArrayId)
        }.toMap()
        Log.d("Howard","map:$regionMap")

    }
    fun plan2(position:Int){
         val regionArray =  regionMap[position]
            var tmpAdapter:ArrayAdapter<String>
        regionArray?.let {
            //?: regionSpinner.adapter 為null 要做什麼事
            tmpAdapter = ( regionSpinner.adapter ?:ArrayAdapter<String>(this,
                    R.layout.spinner_layout,R.id.cityTextView) )
                    as ArrayAdapter<String>
            regionSpinner.adapter = tmpAdapter
            tmpAdapter.clear()
            //*regionArray 表示展開regionArray 放入參數
            tmpAdapter.addAll(*regionArray)

        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val citys =  resources.getStringArray(R.array.city)
        val adapter = ArrayAdapter<String>(this,
                R.layout.spinner_layout,
                R.id.cityTextView,
                citys)
        citySpinner.adapter =adapter
        initRegionMap()

        citySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {
                Log.d("Howard","Empty")
            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Log.d("Howard","position:$position")
                plan2(position)
            }
        }
    }
};