package tw.com.xvpower.ch15_adapter1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private int[] regionArray = {R.array.region_0,
                                 R.array.region_1,
                                 R.array.region_2 };
    private HashMap<Integer,String[]>  regionMap = new HashMap<>();

    //缺點
    // 每次都要 重新取得regionArray
    // 每次都要 建立新Adapter
    private void plan1(int regionArrayId,Spinner regionSpinner ){
        String[] tmpRegionArray = getResources().getStringArray(regionArray[regionArrayId]);
        ArrayAdapter<String> arrayAdapter =
                new ArrayAdapter
                        <String>(MainActivity.this,
                        android.R.layout.simple_list_item_1,
                        android.R.id.text1,
                        tmpRegionArray);

        regionSpinner.setAdapter(arrayAdapter);
    }
    // Plan2 Step1
    private void plan2InitMap(){
        for (int i =0;i<regionArray.length;i++){
            String[] regions = getResources().getStringArray(regionArray[i]);
            regionMap.put(i,regions);
        }
    }
    private void plan2(int regionArrayId,Spinner regionSpinner ){
        String[]  regionArray = regionMap.get(regionArrayId);
        ArrayAdapter<String> obj = (ArrayAdapter)regionSpinner.getAdapter();
        if (obj == null){
            obj = new ArrayAdapter(this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1);
            regionSpinner.setAdapter(obj);
        }
        obj.clear();
        obj.addAll(regionArray);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String[] cities = getResources().getStringArray(R.array.city);

           Spinner spinner = findViewById(R.id.spinner);
           Spinner regionSpinner  = findViewById(R.id.spinner2);

          TextView msgView =  findViewById(R.id.textMsg);
        ArrayAdapter<String> arrayAdapter =
                new ArrayAdapter(this,
                        android.R.layout.simple_list_item_1,
                        android.R.id.text1,cities);
        spinner.setAdapter(arrayAdapter);

        plan2InitMap();

//cannot be used with a spinner.
//        spinner.setOnItemClickListener((ad,view,position,id)->{
//            Log.d("Howard","position:"+position);
//
//        });
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    Log.d("Howard","position:"+position);
              // plan1(position,regionSpinner);
                plan2(position,regionSpinner);
                msgView.setText(cities[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Log.d("Howard","Empty!");
            }
        });


    }
}