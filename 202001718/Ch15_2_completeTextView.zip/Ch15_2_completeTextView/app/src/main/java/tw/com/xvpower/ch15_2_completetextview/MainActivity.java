package tw.com.xvpower.ch15_2_completetextview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    String[] imageString = new String[9];
    private void initArray(){
        String image = "image";
        for (int i =1; i <=imageString.length;i++){
            imageString[i-1] =image+i;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initArray();
       AutoCompleteTextView auct =  findViewById(R.id.imageNameCT);
        auct.setThreshold(1);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line,
                android.R.id.text1,
                imageString);
        auct.setAdapter(adapter);

        ImageView imageView = findViewById(R.id.imageView);
        auct.setOnItemClickListener( (parent,view,position,id)->{
              String name =
                      parent.getItemAtPosition(position).toString();
             int resId =
                     getResources().getIdentifier(name,"drawable",
                             getPackageName());
            imageView.setImageResource(resId);
        });

    }

}