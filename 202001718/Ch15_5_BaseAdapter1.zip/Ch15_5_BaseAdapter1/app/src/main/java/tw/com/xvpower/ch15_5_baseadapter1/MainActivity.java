package tw.com.xvpower.ch15_5_baseadapter1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      ListView listView =  findViewById(R.id.listView);
      ArrayList<String> list = new ArrayList();
        list.add("Test1");
        list.add("Test2");
        list.add("Test3");
        list.add("Test4");
        list.add("Test5");
      TextBaseAdapter tba = new TextBaseAdapter(this,list);
        listView.setAdapter(tba);
        listView.setOnItemClickListener((parent,view,position,id)->{
            TextBaseAdapter tba2 = (TextBaseAdapter)parent.getAdapter();
            String name = tba2.getItem(position);
            Log.d("Howard","name:"+name);
            AlertDialog.Builder builder =
                    new AlertDialog.Builder(this);
            builder.setTitle("刪除資料");
            builder.setMessage("確定是否刪除");
            builder.setPositiveButton("確定",(dialog,which)->{
                tba2.delete(position);
            });
            builder.setNegativeButton("取消",null);
            builder.create().show();

        });
    }
}