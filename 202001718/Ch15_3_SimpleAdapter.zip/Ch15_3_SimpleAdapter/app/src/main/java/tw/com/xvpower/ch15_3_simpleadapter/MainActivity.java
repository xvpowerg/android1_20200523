package tw.com.xvpower.ch15_3_simpleadapter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView =  findViewById(R.id.listView);
        int[] to = {R.id.imageView,R.id.msgText};
        String[] from = {"image","msg"};

        List<Map<String,Object>> data = new ArrayList<>();

        for (int i =1;i<=9;i++){
            Map<String,Object> myMap1 = new HashMap<>();
            String name = "image"+i;
            int resId =  getResources().
                  getIdentifier(name,"drawable",getPackageName());
            myMap1.put("image",resId);
            myMap1.put("msg",name);
            data.add(myMap1);
        }
        /*
        Context context, List<? extends Map<String, ?>> data,
            @LayoutRes int resource, String[] from, @IdRes int[] to
         */
        SimpleAdapter simpleAdapter =
                    new SimpleAdapter(this,data,
                            R.layout.list_layout,from,to);
        listView.setAdapter(simpleAdapter);

        listView.setOnItemClickListener((pa,view,position,id)->{
                    Log.d("Howard","position:"+position);

    });

    //setOnItemSelectedListener 無作用 沒Exception
//        listView.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                Log.d("Howard","position:"+position);
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });
    }
}