package tw.com.xvpower.ch15_4_simpadapter2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.SimpleAdapter;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner spinner = findViewById(R.id.spinner);
        List<Map<String,Object>> list = new ArrayList<>();

        for (int i = 1; i<= 9;i++){
            Map<String,Object> map = new HashMap<>();
            String name = "image"+i;
            int resId = getResources().getIdentifier(name,"drawable",
                    getPackageName());
            map.put("title","Title:"+name);
            map.put("msg",name);
            map.put("image",resId);
            list.add(map);
        }
        //list.add();

        String[] form = {"title","msg","image"};
        int[] to = {R.id.titleView,R.id.msgView,R.id.imageView};

        SimpleAdapter sma = new SimpleAdapter(this,list,
                R.layout.simple_adapter_layout,form,to);
        spinner.setAdapter(sma);


    }
}