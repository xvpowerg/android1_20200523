package tw.com.xvpower.test_fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ButtonsFragment extends Fragment {
    //onCreateView 之前都找不到view


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.buttons_layout,container,false);
    }

    public void initBtnOnclick(View.OnClickListener v){
       Button btn1 =  getView().findViewById(R.id.image1Btn2);
        Button btn2 =  getView().findViewById(R.id.image2Btn2);
        Button btn3 =  getView().findViewById(R.id.image3Btn2);
        btn1.setOnClickListener(v);
        btn2.setOnClickListener(v);
        btn3.setOnClickListener(v);
    }
}
