package tw.com.xvpower.test_adnroidthread;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private TextView text;
    private ImageView imageView;
    private Handler handler = new Handler();
    int i = 1;
    private void startBtnForThread1(View view){
        // thread 1
        Runnable run = ()-> {
            for (i = 1; i <= 5; i++) {
                int id =
                        getResources().getIdentifier("image"+i,
                                "drawable",getPackageName());

                runOnUiThread(()->{
                    Log.d("Howard","runOnUiThread Thread:"+
                            Thread.currentThread().getName());
                    text.setText(i + "");
                    imageView.setImageResource(id);
                });

                Log.d("Howard","NewThread Thread:"+Thread.currentThread().getName());
                try{
                    TimeUnit.SECONDS.sleep(1);
                }catch (Exception ex){
                }
            }
        };
        Thread th1 = new Thread(run);
        th1.start();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button startBtn = findViewById(R.id.startBtn);
        Button startBn2 = findViewById(R.id.start2Btn);

        text = findViewById(R.id.msgTxt);
        imageView = findViewById(R.id.imageView);
        MyViewHandler viewHandler = new MyViewHandler(text,imageView);
        //1 可使用runOnUiThread 解決new Thread 控制UI的問題
        startBtn.setOnClickListener(this::startBtnForThread1);
        //2
        startBn2.setOnClickListener(viewHandler::startBtnForHandler);
    }
}