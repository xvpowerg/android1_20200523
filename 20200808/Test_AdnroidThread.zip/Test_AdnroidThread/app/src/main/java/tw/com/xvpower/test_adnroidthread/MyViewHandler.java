package tw.com.xvpower.test_adnroidthread;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.concurrent.TimeUnit;

public class MyViewHandler {
    private TextView textView;
    private ImageView imageView;
    private int i =1;
    private Context context;
    //會記錄Handler new的執行序是什麼
   private Handler handler = new Handler();

    @SuppressLint("HandlerLeak")
    private Handler messageHandler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {

            switch(msg.what){
                case R.id.msgTxt:
                    textView.setText(msg.obj.toString());
                    break;
                case R.id.imageView:
                    imageView.setImageResource(msg.arg1);
                    break;
            }
        }
    };
    public MyViewHandler(TextView textView, ImageView imageView){
            this.textView = textView;
            this.imageView = imageView;
            context = textView.getContext();
    }

    public void startBtnForHandler(View view){
        //Handler handler = new Handler();
        Runnable run = ()->{
            for (i= 1; i<=5;i++){
                int id =
                        context.getResources().getIdentifier("image"+i,
                                "drawable",context.getPackageName());
                Message txtMsg = new Message();
                txtMsg.what = R.id.msgTxt;
                txtMsg.obj = i+"";

                Message imageMsg = new Message();
                imageMsg.what = R.id.imageView;
                imageMsg.arg1 = id;

                messageHandler.sendMessage(txtMsg);
                messageHandler.sendMessage(imageMsg);
                Log.d("Howard","Other Thread:"+Thread.currentThread().getName());
                try{
                    TimeUnit.SECONDS.sleep(1);
                }catch(Exception ex){}

            }
        };

        Thread th = new Thread(run);
        th.start();
    }



//    public void startBtnForHandler(View view){
//        //Handler handler = new Handler();
//        Runnable run = ()->{
//            for (i= 1; i<=5;i++){
//                int id =
//                        context.getResources().getIdentifier("image"+i,
//                                "drawable",context.getPackageName());
//                handler.post(()->{
//                    textView.setText(i+"");
//                    imageView.setImageResource(id);
//                });
//
//                Log.d("Howard","Other Thread:"+Thread.currentThread().getName());
//                try{
//                    TimeUnit.SECONDS.sleep(1);
//                }catch(Exception ex){}
//
//            }
//        };
//
//        Thread th = new Thread(run);
//        th.start();
//    }

}
