package tw.com.xvpower.notifiaction;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private String CHANNEL_ID="msgID";
    private void createNotificationChannel(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationManager nm =
                    (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
           //如果Channel存在就不建立新的Channel
            NotificationChannel tmpCh =
                    nm.getNotificationChannel(CHANNEL_ID);
            if (tmpCh != null){
                return;
            }
            //如果Channel不存在就建立新的Channel
            String name ="TestNotifiName" ;
            String desName = "Test Notification";
            int importance =
                     NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel notificationChannel =
                    new NotificationChannel(CHANNEL_ID,name,importance);
            notificationChannel.setDescription(desName);
            nm.createNotificationChannel(notificationChannel);
        }

    }


    private void  testNotification1(View vie){
        //可辨識訊息是否相同
        int id = 1;
        NotificationCompat.Builder nb =
                new NotificationCompat.Builder(this,CHANNEL_ID);
        nb.setSmallIcon(R.drawable.msg);
        nb.setContentTitle("Title");
        nb.setContentText("為了降低零售價，很多廠商在推出中低階手機時，往往都會採用成本" +
                "較便宜的 LCD 螢幕，不過先前發表的 Pixel 4a 則例外，雖然定價只需台幣" +
                        " 11,990 元，但螢幕依然配備 OLED 面板，有分析師就解構 Google 是如何做" +
                        "到的。顯示器分析機構 DSCC 的分析師 Ross Young 認為，Google 為 Pixel 4 " +
                        "選擇了硬質 OLED 面板，而不是 Apple 為 iPhone 所選用的柔性 OLED 面板，" +
                        "前者的價格只有後者的三分一。他解釋，柔性 OLED 面板的好處是下邊框比較窄，" +
                        "但 Pixel 4a 屬於中階定位，顧客比較不在意邊框寬度。此外，他估計 Google " +
                        "只從單一面板生產商採購，也有助壓低零件成本，跟蘋果向多間供應商取貨不同。!");
        nb.setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManagerCompat.from(this).notify(id,
                                    nb.build());
    }
    private void testNotification2(View view){
        int id = 2;
        NotificationCompat.Builder nb =
                new NotificationCompat.Builder(this,CHANNEL_ID);
        nb.setSmallIcon(R.drawable.msg2);
        nb.setContentTitle("Big Text");
        //大文字樣式
        NotificationCompat.BigTextStyle bigStyle =  new
                NotificationCompat.BigTextStyle().
                bigText("為了降低零售價，很多廠商在推出中低階手機時，往往都會採用成本" +
                        "較便宜的 LCD 螢幕，不過先前發表的 Pixel 4a 則例外，雖然定價只需台幣" +
                        " 11,990 元，但螢幕依然配備 OLED 面板，有分析師就解構 Google 是如何做" +
                        "到的。顯示器分析機構 DSCC 的分析師 Ross Young 認為，Google 為 Pixel 4 " +
                        "選擇了硬質 OLED 面板，而不是 Apple 為 iPhone 所選用的柔性 OLED 面板，" +
                        "前者的價格只有後者的三分一。他解釋，柔性 OLED 面板的好處是下邊框比較窄，" +
                        "但 Pixel 4a 屬於中階定位，顧客比較不在意邊框寬度。此外，他估計 Google " +
                        "只從單一面板生產商採購，也有助壓低零件成本，跟蘋果向多間供應商取貨不同。!");
        nb.setStyle(bigStyle);
        nb.setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManagerCompat.from(this).notify(id,nb.build());
    }


    private void  testNotification3(View vie){
        int id = 3;
        //使用此requestCode 判定是否為相同的Intent
        int requestCode = 100;
        Intent openActivityIntent = new  Intent(this,
                TestNotificationActivity.class);
        openActivityIntent.putExtra("msg","為了降低零售價，很多廠商在推出中低階手機時，往往都會採用成本" +
                "較便宜的 LCD 螢幕，不過先前發表的 Pixel 4a 則例外，雖然定價只需台幣" +
                " 11,990 元，但螢幕依然配備 OLED 面板，有分析師就解構 Google 是如何做" +
                "到的。顯示器分析機構 DSCC 的分析師 Ross Young 認為，Google 為 Pixel 4 " +
                "選擇了硬質 OLED 面板，而不是 Apple 為 iPhone 所選用的柔性 OLED 面板，" +
                "前者的價格只有後者的三分一。他解釋，柔性 OLED 面板的好處是下邊框比較窄，" +
                "但 Pixel 4a 屬於中階定位，顧客比較不在意邊框寬度。此外，他估計 Google " +
                "只從單一面板生產商採購，也有助壓低零件成本，跟蘋果向多間供應商取貨不同。!");

        openActivityIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_CLEAR_TASK);
        //PendingIntent.FLAG_UPDATE_CURRENT 會將目前的Intent做更新
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,requestCode,
                openActivityIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);

//        NotificationCompat.Builder nb = new
//                NotificationCompat.Builder(this,CHANNEL_ID);
//        nb.setSmallIcon(R.drawable.msg3);
//        nb.setContentTitle("Notification Title!");
//        nb.setContentText("您有新的郵件");
//        nb.setPriority(NotificationCompat.PRIORITY_MAX);
//        nb.setContentIntent(pendingIntent);
//        nb.setAutoCancel(true);//按下 Notification 後會自動關閉
        Notification n = new
                NotificationCompat.Builder(this,CHANNEL_ID)
                .setSmallIcon(R.drawable.msg3).
                setContentTitle("Notification Title!").
                        setContentText("您有新的郵件").
                        setPriority(NotificationCompat.PRIORITY_MAX).
                        setContentIntent(pendingIntent).
                        setAutoCancel(true).build();
        NotificationManagerCompat.from(this).notify(id,
                n);

    }

    private int count = 1;
    private void  testNotification4(View vie){
        int max =100;
        int id = 4;
        count+=10;
            NotificationCompat.Builder builder =
                    new NotificationCompat.Builder(this,CHANNEL_ID);
        builder.setContentTitle("Download....");
        builder.setContentText("Download in Progress!:"+count);
        builder.setSmallIcon(R.drawable.msg4);
        builder.setPriority(NotificationCompat.PRIORITY_LOW);

        Runnable run = ()->{
            for (int i =10; i<=100; i+=10){
                builder.setProgress(max,i,false);
                NotificationManagerCompat.from(this).notify(id,builder.build());
                try{
                    Thread.sleep(1000);
                }catch (Exception ex){
                    System.out.println(ex);
                }
            }
            builder.setContentText("完成");
            builder.setProgress(0,0,false);
            NotificationManagerCompat.from(this).notify(id,builder.build());
        };

        Thread thread = new Thread(run);
        thread.start();


    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn1 = findViewById(R.id.Notifi1Btn);
        Button btn2 = findViewById(R.id.Notifi2Btn);
        Button btn3 = findViewById(R.id.Notifi3Btn);
        Button btn4 = findViewById(R.id.Notifi4Btn);
        createNotificationChannel();
        btn1.setOnClickListener(this::testNotification1);
        btn2.setOnClickListener(this::testNotification2);
        //Open New Activity
        btn3.setOnClickListener(this::testNotification3);
        btn4.setOnClickListener(this::testNotification4);
    }
}