package tw.com.xvpower.notifiaction;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class TestNotificationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_notification_activtiy);
     TextView textView =  findViewById(R.id.msgView);
     String msg =   getIntent().getStringExtra("msg");
        textView.setText(msg);
    }
}