package tw.com.xvpower.ch17_4_seekbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView textView1,textView2,textView3;
        private class MySeekBarChangeListener implements SeekBar.OnSeekBarChangeListener {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                Log.d("Howard","progress:"+progress);
                switch(seekBar.getId()){
                    case R.id.seekBar1:
                        textView1.setText(progress+"");
                        break;
                    case R.id.seekBar2:
                        textView2.setText(progress+"");
                        break;
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                Log.d("Howard","onStartTrackingTouch");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Log.d("Howard","onStopTrackingTouch");
            }
        }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       SeekBar seekBar1 =  findViewById(R.id.seekBar1);
       SeekBar seekBar2 = findViewById(R.id.seekBar2);
        textView1 = findViewById(R.id.seekBar1Text);
        textView2 = findViewById(R.id.seekBar2Text);
        textView3 = findViewById(R.id.ratingBarText);
       seekBar1.setMax(100);
       seekBar2.setMax(10);

       MySeekBarChangeListener listener = new MySeekBarChangeListener();
       seekBar1.setOnSeekBarChangeListener(listener);
       seekBar2.setOnSeekBarChangeListener(listener);

       RatingBar ratingBar =  findViewById(R.id.ratingBar);
       ratingBar.setNumStars(5);

        ratingBar.setOnRatingBarChangeListener((rb,rating,fromUser)->{
            Log.d("Howard","rating:"+rating);
            String msg = "請給分數優!";
            if (rating <= 1){
                msg = "請給分數優!";
            }else if (rating <= 2){
                msg = "要加油";
            }else if(rating <= 4){
                msg = "還不錯";
            }else if(rating <=5){
                msg = "很棒";
            }
            textView3.setText(msg);
        });

    }
}