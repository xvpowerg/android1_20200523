package tw.com.xvpower.ch17_3_progressbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Switch;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private class MyProgressBarRun implements Runnable{
        private boolean isRun = true;
        private ProgressBar  progressBar = null;
        //Handler 會紀錄new時的執行序
        private Handler handler = new Handler();
        private View view;
        private int i =5;
        public MyProgressBarRun( ProgressBar  progressBar,View view){
            this.progressBar = progressBar;
            this.view = view;
        }
        public void stop(){
            isRun = false;
        }
        public void start(){
            isRun = true;
        }
        public void reset(){
            i = 5;
        }
        //
        @Override
        public void run() {
            //在android內 使用自定義執行序操作UI 是不安全的
            //必須轉換到main Thread
            runOnUiThread(()->{
                view.setEnabled(false);
            });


            for ( ;isRun && i <= 100; i+=5){
                handler.post(()->progressBar.setProgress(i));
                try{
                    TimeUnit.SECONDS.sleep(1);
                }catch (InterruptedException ex){ }
            }
            runOnUiThread(()->{
                view.setEnabled(true);
            });

        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ProgressBar  progressBar = findViewById(R.id.progressBar1);
       Switch switch1 =  findViewById(R.id.switch1);
        switch1.setOnCheckedChangeListener((btnView,isChecked)->{
                if (isChecked){
                    progressBar.setVisibility(View.VISIBLE);
                }else{
                    progressBar.setVisibility(View.INVISIBLE);
                }

        });
             ProgressBar progressBar2 = findViewById(R.id.progressBar2);
        progressBar2.setMax(100);

       Button startBtn =   findViewById(R.id.startBtn);
       Button stopBtn =   findViewById(R.id.stopBtn);
      Button resetBtn =  findViewById(R.id.resetBtn);
        MyProgressBarRun myProgressBarRun =
                new MyProgressBarRun(progressBar2,startBtn);
        startBtn.setOnClickListener(v->{
            myProgressBarRun.start();
            Thread t1  = new Thread(myProgressBarRun);
            t1.start();

            //progressBar2.incrementProgressBy(5);
            //progressBar2.setProgress(5);
        });
        stopBtn.setOnClickListener(v->{
            myProgressBarRun.stop();
        });
        resetBtn.setOnClickListener(v->{
            progressBar2.setProgress(0);
            myProgressBarRun.reset();

        });


    }
}