package tw.com.xvpower.ch17_1_baseadapter

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_detail.*
import tw.com.xvpower.ch17_1_baseadapter.data.ImageInfo

class ImageDetailActivity: AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       setContentView(R.layout.activity_detail)
    }

    override fun onStart() {
        super.onStart()
      val imageInfo =
          intent.getParcelableExtra<ImageInfo>("imageInfo")
        detailImageView.setImageResource(imageInfo.imageId)
        imageInfoTxt.text = imageInfo.name
        imageDetailTxt.text = imageInfo.detail

//       val imageId =  intent.getIntExtra("imageId",-1)
//        val name = intent.getStringExtra("name")
//        val imageDetail = intent.getStringExtra("imageDetail")
//       detailImageView.setImageResource(imageId)
//       imageInfoTxt.text = name
//       imageDetailTxt.text = imageDetail

    }

}