package tw.com.xvpower.ch17_1_baseadapter

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import tw.com.xvpower.ch17_1_baseadapter.data.ImageAdapter
import tw.com.xvpower.ch17_1_baseadapter.data.ImageInfo

class MainActivity : AppCompatActivity() {
    private fun initImageInfoList():List<ImageInfo>{
          val imageNameArray =
              resources.getStringArray(R.array.image_txt)
        val imageDetailArray =  resources.getStringArray(R.array.image_txt_detail)
       return  imageNameArray.mapIndexed {index,imageName->
           val imageDetailStr = imageDetailArray[index]
           val imageId =  resources.getIdentifier(imageName,
                    "drawable",
                            packageName)
            val imageInfo = ImageInfo(imageName,imageDetailStr,imageId)
            imageInfo
        }.toList()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onStart() {
        super.onStart()
        val list = initImageInfoList()
        val imageAdapter = ImageAdapter(list,this)
        listVIew.adapter =imageAdapter
        listVIew.setOnItemLongClickListener {
                parent, view, position, id ->
                    Toast.makeText(this,"長按:"+position,
                        Toast.LENGTH_SHORT).show()
             //false 如果有多個Listener 都會執行
            //true 只會接收LongClickListener
                 true
        }
        listVIew.setOnItemClickListener { parent, view, position, id ->
           val imageInfo =  parent.adapter.getItem(position) as ImageInfo
           // Toast.makeText(this,imageInfo.name,Toast.LENGTH_SHORT).show()
          // Toast.makeText(this,list[position].name,Toast.LENGTH_SHORT).show()
           val intent = Intent(this,
               ImageDetailActivity::class.java)
            intent.putExtra("imageInfo",imageInfo)

//            intent.putExtra("name",imageInfo.name)
//            intent.putExtra("imageDetail",imageInfo.detail)
//            intent.putExtra("imageId",imageInfo.imageId)
            startActivity(intent)
        }
    }
}