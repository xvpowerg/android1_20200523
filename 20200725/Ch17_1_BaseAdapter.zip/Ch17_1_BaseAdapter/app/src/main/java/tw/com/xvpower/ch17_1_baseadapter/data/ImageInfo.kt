package tw.com.xvpower.ch17_1_baseadapter.data

import android.os.Parcel
import android.os.Parcelable

data class ImageInfo(val name: String?, val detail:String?,
                     val imageId:Int):Parcelable {

    constructor(parcel: Parcel):this(parcel.readString(),
        parcel.readString(),
        parcel.readInt())


    override fun describeContents(): Int {
        return 0;
    }
    // 序列化  物件變檔案
    override fun writeToParcel(dest: Parcel?, flags: Int) {
        dest?.run {
            writeString(name)
            writeString(detail)
            writeInt(imageId)
        }
    }
//反序列化 檔案變物件
        companion object CREATOR :Parcelable.Creator<ImageInfo>{
            override fun createFromParcel(source: Parcel): ImageInfo? {
               return ImageInfo(source)
            }

            override fun newArray(size: Int): Array<ImageInfo?> {
              return arrayOfNulls(size)
            }

        }



}