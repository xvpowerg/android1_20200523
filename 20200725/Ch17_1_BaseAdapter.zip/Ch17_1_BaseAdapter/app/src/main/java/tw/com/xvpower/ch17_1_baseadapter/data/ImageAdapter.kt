package tw.com.xvpower.ch17_1_baseadapter.data

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import tw.com.xvpower.ch17_1_baseadapter.R

class ImageAdapter(val list:List<ImageInfo>,
                   val context:Context) : BaseAdapter() {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
       val view =  LayoutInflater.from(context).inflate(R.layout.list_layout,
            parent,false)
        val imageView = view.findViewById<ImageView>(R.id.imageView)
        val imageInfoTxt =  view.findViewById<TextView>(R.id.imageInfo)
        val imageInfo = list[position]
        imageView.setImageResource(imageInfo.imageId)
        imageInfoTxt.text = imageInfo.name
        return view
    }

    override fun getItem(position: Int): ImageInfo {
            return  list[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return list.size
    }
}