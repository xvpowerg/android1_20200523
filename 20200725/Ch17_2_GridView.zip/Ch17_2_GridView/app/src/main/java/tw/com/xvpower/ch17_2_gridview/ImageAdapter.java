package tw.com.xvpower.ch17_2_gridview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ImageAdapter extends BaseAdapter {
    private List<ImageInfo> imageInfoList = new ArrayList<>();

    public void addImageInfo(ImageInfo imageInfo){
        imageInfoList.add(imageInfo);
    }
    @Override
    public int getCount() {
        return imageInfoList.size();
    }
    @Override
    public ImageInfo getItem(int position) {
        return imageInfoList.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
       ImageInfo imageInfo =    getItem(position);
        Context context =  parent.getContext();
        View view = LayoutInflater.from(context).
                inflate(R.layout.grid_view_layout,parent,
                        false);
        ImageView imageView =  view.findViewById(R.id.imageView);
       TextView imageInfoView = view.findViewById(R.id.imageInfoTxt);
        imageView.setImageResource(imageInfo.getImageId());
        imageInfoView.setText(imageInfo.getImageText());
        return view;
    }
}
