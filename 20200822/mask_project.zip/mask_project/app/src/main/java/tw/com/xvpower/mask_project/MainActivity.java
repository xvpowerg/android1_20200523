package tw.com.xvpower.mask_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.google.gson.Gson;

import java.util.ArrayList;

import tw.com.xvpower.mask_project.adapter.MaskAdapter;
import tw.com.xvpower.mask_project.bean.UserInfo;
import tw.com.xvpower.mask_project.bean.mask.Feature;
import tw.com.xvpower.mask_project.json.MaskJsonTools;
import tw.com.xvpower.mask_project.listener.MyLocationListener;
import tw.com.xvpower.mask_project.net.DownloadMaskJson;

public class MainActivity extends AppCompatActivity {
    private ProgressBar loadJsonProgressBar;
    private ListView maskListView;
    private LocationManager locationManager;
    private MyLocationListener myLocation;
    private MaskAdapter ma;
    void testJson(){
        String json = "{\n" +
                "     \"firstName\": \"John\",\n" +
                "     \"lastName\": \"Smith\",\n" +
                "     \"sex\": \"male\",\n" +
                "     \"age\": 25,\n" +
                "     \"address\": \n" +
                "     {\n" +
                "         \"streetAddress\": \"21 2nd Street\",\n" +
                "         \"city\": \"New York\",\n" +
                "         \"state\": \"NY\",\n" +
                "         \"postalCode\": \"10021\"\n" +
                "     },\n" +
                "     \"phoneNumber\": \n" +
                "     [\n" +
                "         {\n" +
                "           \"type\": \"home\",\n" +
                "           \"number\": \"212 555-1234\"\n" +
                "         },\n" +
                "         {\n" +
                "           \"type\": \"fax\",\n" +
                "           \"number\": \"646 555-4567\"\n" +
                "         }\n" +
                "     ]\n" +
                " }";

        Gson gson = new Gson();
        UserInfo userInfo =   gson.fromJson(json,UserInfo.class);
        Log.d("Howard","userInfo:"+userInfo);
    }



    @SuppressLint("MissingPermission")
    private void addLocationListener(){
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                2000L,0f,myLocation);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,2000L,0f,
                myLocation);
    }

    private void checkGPSPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_FINE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED){
            addLocationListener();
    //
    }else{
            ActivityCompat.requestPermissions(this,
                    new String[]{ Manifest.permission.ACCESS_COARSE_LOCATION,
                            Manifest.permission.ACCESS_FINE_LOCATION},
                    100);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loadJsonProgressBar = findViewById(R.id.progressBar);
        maskListView = findViewById(R.id.maskList);
        locationManager =
                (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        myLocation = new MyLocationListener(location->{
            Feature.setLocation(location);
            ma.sort();
            if (maskListView.getAdapter() == null){
                maskListView.setAdapter(ma);
            }
            loadJsonProgressBar.setVisibility(View.GONE);
        });
        //testJson();
        //認識Json
        //使用Java分析Json方式
        //如何取得Json
        //了解目前Json檔案資料架構
        //使用Json產生物件
        //將物件顯示於畫面
        //排序
        //導航
    }


    @Override
    protected void onStart() {
        super.onStart();
        String jsonUrl =  getString(R.string.mask_json_url);
        DownloadMaskJson dmj =
                new DownloadMaskJson(jsonUrl);

        dmj.setDownloadCallBack(json->{
            MaskJsonTools.jsonToObject(json,maskData->{
                ma = new MaskAdapter(maskData);
                runOnUiThread(()->{
                    checkGPSPermission();
                });

            });
        });
        dmj.start();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
            if (grantResults!= null && grantResults.length >1 &&
                    (grantResults[0] == PackageManager.PERMISSION_GRANTED
                            || grantResults[1] == PackageManager.PERMISSION_GRANTED)){
                addLocationListener();
            }

    }
}