package tw.com.xvpower.mask_project.net;

import android.util.Log;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class DownloadMaskJson {
    private String jsonUrl ="";
    public DownloadMaskJson(String jsonUrl){
            this.jsonUrl = jsonUrl;
    }
    private DownloadMaskJsonFinish dmfCallBack;
    public static interface DownloadMaskJsonFinish{
         void callBack(String json);
    }
    public void setDownloadCallBack(DownloadMaskJsonFinish dmfCallBack){
        this.dmfCallBack = dmfCallBack;
    }

    private class OkHttpCallBack implements Callback {

        @Override
        public void onFailure(@NotNull Call call, @NotNull IOException e) {
            Log.e("Howard","onFailure!"+e);
        }

        @Override
        public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
             String json =  response.body().string();
             if (dmfCallBack != null){
                 dmfCallBack.callBack(json);
             }
        }
    }
    public void start(){
        OkHttpClient.Builder okb = new OkHttpClient.Builder();
        OkHttpClient client = okb.retryOnConnectionFailure(true).
                readTimeout(10, TimeUnit.SECONDS).
                build();
        Request.Builder rb = new Request.Builder();
        Request request =  rb.url(jsonUrl).build();
        client.newCall(request).enqueue(new OkHttpCallBack());

    }

}
