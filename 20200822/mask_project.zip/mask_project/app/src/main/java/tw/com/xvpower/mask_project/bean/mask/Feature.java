package tw.com.xvpower.mask_project.bean.mask;

import android.location.Location;

public class Feature {

    private static Location location;
    private Properties properties;
    private Geometry geometry;
    public static void setLocation(Location location){
        Feature.location = location;
    }
    public float getDistance(){
        if (location == null) return 0;
        float[] result = {0};
        Location.distanceBetween(location.getLatitude(),
                location.getLongitude(),
                geometry.getLat(),geometry.getLon(),result);
        return result[0];
    }

    public String getDistanceToKmString(){
        return  String.format("%.2f Km",getDistance() / 1000) ;
    }
    public Properties getProperties() {
        return properties;
    }

    public Geometry getGeometry() {
        return geometry;
    }
}
