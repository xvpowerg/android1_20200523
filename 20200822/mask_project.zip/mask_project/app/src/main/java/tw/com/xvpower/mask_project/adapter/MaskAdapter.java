package tw.com.xvpower.mask_project.adapter;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.Comparator;
import java.util.List;

import tw.com.xvpower.mask_project.R;
import tw.com.xvpower.mask_project.bean.mask.Feature;
import tw.com.xvpower.mask_project.bean.mask.MaskData;

public class MaskAdapter extends BaseAdapter {
    private List<Feature> fList;
    public MaskAdapter(MaskData maskData){
        fList = maskData.getFeatures();
    }
    @Override
    public int getCount() {
        return fList.size();
    }

    @Override
    public Feature getItem(int position) {
        return fList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
       View view =    LayoutInflater.from(parent.getContext()).
                  inflate(R.layout.mask_adapter_layout,parent,false);
        TextView nameText =  view.findViewById(R.id.nameText);
        TextView phoneText =   view.findViewById(R.id.phone);
        TextView addressText = view.findViewById(R.id.address);
        TextView adultText =  view.findViewById(R.id.adult);
        TextView childText =  view.findViewById(R.id.child);
        TextView distanceTxt =  view.findViewById(R.id.distanceTxt);

        Feature feature =   getItem(position);
        nameText.setText(feature.getProperties().getName());
        phoneText.setText(feature.getProperties().getPhone());
        addressText.setText(feature.getProperties().getAddress());
        distanceTxt.setText(feature.getDistanceToKmString());
        int adultCount = feature.getProperties().getMask_adult();
        int childCount = feature.getProperties().getMask_child();

       if (adultCount < 100){
            adultText.setTextColor(Color.RED);
        }
        if (childCount < 100){
            childText.setTextColor(Color.RED);
        }
        adultText.setText("成人:"+adultCount);
        childText.setText("兒童:"+childCount+"");

        return view ;
    }

    public void sort(){
        Comparator<Feature> cmp =
                Comparator.comparing(f->f.getDistance());
        fList.sort(cmp);
        //改變ListView的畫面
         notifyDataSetChanged();
    }
}
