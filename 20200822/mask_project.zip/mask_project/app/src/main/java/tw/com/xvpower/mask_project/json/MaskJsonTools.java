package tw.com.xvpower.mask_project.json;

import com.google.gson.Gson;

import java.util.function.Consumer;

import tw.com.xvpower.mask_project.bean.mask.MaskData;

public class MaskJsonTools {

    public static void jsonToObject(String maskJson,Consumer<MaskData> consumer){
        Gson gson = new Gson();
        Thread thread = new  Thread(()->{
            MaskData maskData =
                    gson.fromJson(maskJson, MaskData.class);
            consumer.accept(maskData);
        });
        thread.start();

    }

}
