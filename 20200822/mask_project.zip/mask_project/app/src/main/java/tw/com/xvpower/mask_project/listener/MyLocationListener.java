package tw.com.xvpower.mask_project.listener;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.util.Log;

import java.util.function.Consumer;

import tw.com.xvpower.mask_project.bean.mask.Feature;

public class MyLocationListener implements LocationListener {
      private Consumer<Location> callBack;

      public MyLocationListener(Consumer<Location> callBack){
          this.callBack = callBack;
      }

    @Override
    public void onLocationChanged(Location location) {
        callBack.accept(location);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
