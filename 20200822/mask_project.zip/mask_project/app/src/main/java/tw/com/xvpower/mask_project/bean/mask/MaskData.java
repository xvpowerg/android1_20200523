package tw.com.xvpower.mask_project.bean.mask;

import java.util.ArrayList;

public class MaskData {
    private ArrayList<Feature> features;
    public  ArrayList<Feature> getFeatures(){

        return features;
    }
}
