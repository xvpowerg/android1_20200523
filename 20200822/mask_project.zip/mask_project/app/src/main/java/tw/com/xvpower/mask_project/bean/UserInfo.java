package tw.com.xvpower.mask_project.bean;

import java.util.ArrayList;
import java.util.function.Consumer;

public class UserInfo {
    private String firstName;
    private String lastName;
    private String sex;
    private int age;
    private Address address;
    private ArrayList<Phone> phoneNumber;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void addPhone(Phone phone){
        phoneNumber.add(phone);
    }
    public void forEachPhone(Consumer<Phone> consumer){
        phoneNumber.forEach(consumer);
    }

    @Override
    public String toString() {
        return "UserInfo{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", sex='" + sex + '\'' +
                ", age=" + age +
                ",address="+address+
                ",phoneNumber:"+phoneNumber+
                '}';
    }
}
