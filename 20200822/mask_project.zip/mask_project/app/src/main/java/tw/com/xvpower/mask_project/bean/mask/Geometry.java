package tw.com.xvpower.mask_project.bean.mask;

import java.util.ArrayList;

public class Geometry {
    private ArrayList<Double> coordinates;
    public double getLon(){
        return coordinates.get(0);
    }
    public double getLat(){
        return coordinates.get(1);
    }


}
